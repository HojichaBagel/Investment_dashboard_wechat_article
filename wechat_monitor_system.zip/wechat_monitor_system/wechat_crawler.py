#!/usr/bin/env python3
"""
微信公众号内容抓取与融资信息解析模块

功能：
1. 模拟微信公众号阅读获取最新文章
2. 解析融资相关信息
3. 提取公司、金额、轮次等关键信息
4. 结构化存储解析结果

注意：实际部署时需要考虑微信反爬机制和合规性
"""

import json
import re
import os
import time
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import requests
from bs4 import BeautifulSoup
import sqlite3
import hashlib

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/workspace/logs/wechat_crawler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WeChatArticle:
    """微信公众号文章数据结构"""
    
    def __init__(self, account_name: str, title: str, content: str, url: str, publish_time: str):
        self.account_name = account_name
        self.title = title
        self.content = content
        self.url = url
        self.publish_time = publish_time
        self.article_id = self._generate_id()
        
    def _generate_id(self) -> str:
        """生成文章唯一ID"""
        content = f"{self.account_name}_{self.title}_{self.publish_time}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
        
    def to_dict(self) -> Dict:
        """转换为字典格式"""
        return {
            "article_id": self.article_id,
            "account_name": self.account_name,
            "title": self.title,
            "content_preview": self.content[:200] + "..." if len(self.content) > 200 else self.content,
            "url": self.url,
            "publish_time": self.publish_time,
            "content_length": len(self.content)
        }

class FundingInfoExtractor:
    """融资信息提取器"""
    
    def __init__(self, config_path: str = "/home/workspace/wechat_config.json"):
        """初始化提取器"""
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # 编译正则表达式
        self.patterns = self._compile_patterns()
        
    def _compile_patterns(self) -> Dict:
        """编译所有正则表达式模式"""
        patterns = {}
        
        # 公司名称模式
        company_patterns = []
        for pattern in self.config["parsing_rules"]["company_name_patterns"]:
            company_patterns.append(re.compile(pattern, re.IGNORECASE))
        patterns["company"] = company_patterns
        
        # 融资金额模式
        funding_patterns = []
        for pattern in self.config["parsing_rules"]["funding_amount_patterns"]:
            funding_patterns.append(re.compile(pattern, re.IGNORECASE))
        patterns["funding"] = funding_patterns
        
        # 融资轮次模式
        round_patterns = []
        for pattern in self.config["parsing_rules"]["round_patterns"]:
            round_patterns.append(re.compile(pattern, re.IGNORECASE))
        patterns["round"] = round_patterns
        
        # 投资方模式
        investor_patterns = []
        for pattern in self.config["parsing_rules"]["investor_patterns"]:
            investor_patterns.append(re.compile(pattern))
        patterns["investor"] = investor_patterns
        
        return patterns
    
    def extract_funding_info(self, article: WeChatArticle) -> List[Dict]:
        """
        从文章中提取融资信息
        
        返回: 融资信息列表，每个元素包含公司、金额、轮次等信息
        """
        funding_infos = []
        
        # 组合文章内容进行解析
        full_text = f"{article.title}\n\n{article.content}"
        
        # 尝试找到所有可能的公司-融资组合
        sentences = self._split_into_funding_sentences(full_text)
        
        for sentence in sentences:
            funding_info = self._parse_single_funding(sentence, article)
            if funding_info:
                funding_infos.append(funding_info)
                
        logger.info(f"从文章 '{article.title}' 中提取到 {len(funding_infos)} 条融资信息")
        return funding_infos
    
    def _split_into_funding_sentences(self, text: str) -> List[str]:
        """将文本分割成可能包含融资信息的句子"""
        # 融资相关的关键词
        funding_keywords = [
            "融资", "获投", "投资", "funding", "raised", "investment",
            "千万", "亿元", "百万", "美元", "人民币",
            "轮", "series", "round"
        ]
        
        sentences = []
        # 按句子分割
        raw_sentences = re.split(r'[。！？!?.]\s*', text)
        
        for sentence in raw_sentences:
            # 检查是否包含融资关键词
            if any(keyword in sentence for keyword in funding_keywords):
                sentences.append(sentence.strip())
                
        return sentences
    
    def _parse_single_funding(self, sentence: str, article: WeChatArticle) -> Optional[Dict]:
        """解析单个句子中的融资信息"""
        
        # 提取公司名称
        company_name = self._extract_company_name(sentence)
        if not company_name:
            return None
            
        # 提取融资金额
        funding_amount = self._extract_funding_amount(sentence)
        if not funding_amount:
            return None
            
        # 提取融资轮次
        funding_round = self._extract_funding_round(sentence)
        
        # 提取投资方
        investors = self._extract_investors(sentence)
        
        # 提取行业信息
        industry = self._infer_industry(sentence, article.title)
        
        # 构建融资信息
        funding_info = {
            "company_name": company_name,
            "funding_amount": funding_amount,
            "funding_round": funding_round or "未明确",
            "investors": investors or ["未明确"],
            "industry": industry or "未分类",
            "source_article": article.title,
            "source_account": article.account_name,
            "publish_date": article.publish_time,
            "article_url": article.url,
            "extraction_confidence": self._calculate_confidence(sentence, company_name, funding_amount),
            "extraction_timestamp": datetime.now().isoformat(),
            "raw_sentence": sentence
        }
        
        return funding_info
    
    def _extract_company_name(self, text: str) -> Optional[str]:
        """提取公司名称"""
        for pattern in self.patterns["company"]:
            match = pattern.search(text)
            if match:
                company = match.group(1).strip()
                # 过滤掉一些常见误判
                if len(company) >= 2 and company not in ["公司", "科技", "技术"]:
                    return company
        return None
    
    def _extract_funding_amount(self, text: str) -> Optional[str]:
        """提取融资金额"""
        for pattern in self.patterns["funding"]:
            match = pattern.search(text)
            if match:
                amount = match.group(1).strip()
                # 获取完整的匹配
                full_match = match.group(0)
                
                # 确定货币单位
                currency = "人民币"
                if "美元" in full_match or "USD" in full_match or "$" in full_match:
                    currency = "美元"
                
                # 确定数量级
                magnitude = ""
                if "万" in full_match:
                    magnitude = "万"
                elif "千万" in full_match:
                    magnitude = "千万"
                elif "亿" in full_match:
                    magnitude = "亿"
                elif "百万" in full_match and "美元" not in full_match:
                    magnitude = "百万"
                elif "M" in full_match.upper():
                    magnitude = "百万美元"
                elif "B" in full_match.upper():
                    magnitude = "十亿美元"
                
                return f"{amount}{magnitude}{currency}"
        return None
    
    def _extract_funding_round(self, text: str) -> Optional[str]:
        """提取融资轮次"""
        for pattern in self.patterns["round"]:
            match = pattern.search(text)
            if match:
                return match.group(0).strip()
        return None
    
    def _extract_investors(self, text: str) -> List[str]:
        """提取投资方"""
        investors = []
        for pattern in self.patterns["investor"]:
            match = pattern.search(text)
            if match:
                investor_text = match.group(1).strip()
                # 分割多个投资方
                if "、" in investor_text:
                    investors.extend([inv.strip() for inv in investor_text.split("、")])
                elif "," in investor_text:
                    investors.extend([inv.strip() for inv in investor_text.split(",")])
                elif "和" in investor_text:
                    investors.extend([inv.strip() for inv in investor_text.split("和")])
                else:
                    investors.append(investor_text)
        
        # 去重
        return list(set(investors)) if investors else []
    
    def _infer_industry(self, sentence: str, title: str) -> Optional[str]:
        """推断行业分类"""
        industry_keywords = {
            "人工智能": ["AI", "人工智能", "机器学习", "深度学习", "大模型"],
            "硬科技": ["半导体", "芯片", "集成电路", "机器人", "新能源", "自动驾驶"],
            "医疗健康": ["医疗", "健康", "生物", "医药", "基因", "诊断"],
            "消费": ["消费", "零售", "电商", "品牌", "餐饮", "食品"],
            "企业服务": ["SaaS", "B2B", "企业服务", "云计算", "办公"],
            "金融科技": ["金融", "支付", "保险", "区块链", "数字货币"],
            "教育": ["教育", "培训", "在线教育", "学习"],
            "文娱": ["娱乐", "游戏", "视频", "音乐", "社交"]
        }
        
        combined_text = f"{title} {sentence}".lower()
        
        for industry, keywords in industry_keywords.items():
            for keyword in keywords:
                if keyword.lower() in combined_text:
                    return industry
        
        return None
    
    def _calculate_confidence(self, sentence: str, company: str, amount: str) -> float:
        """计算提取置信度"""
        confidence = 0.5
        
        # 公司名称长度因素
        if len(company) >= 4:
            confidence += 0.1
        
        # 金额明确性因素
        if "万" in amount or "亿" in amount or "美元" in amount:
            confidence += 0.2
        
        # 句子完整性因素
        if len(sentence) >= 20 and len(sentence) <= 200:
            confidence += 0.1
        
        # 关键词密度因素
        funding_keywords = ["融资", "投资", "获投", "funding", "raised"]
        keyword_count = sum(1 for kw in funding_keywords if kw in sentence)
        confidence += min(keyword_count * 0.05, 0.15)
        
        return min(confidence, 1.0)

class WeChatCrawler:
    """微信公众号爬虫（模拟版本）"""
    
    def __init__(self, config_path: str = "/home/workspace/wechat_config.json"):
        """初始化爬虫"""
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.extractor = FundingInfoExtractor(config_path)
        self.db_conn = None
        self._init_database()
        
        # 创建必要的目录
        os.makedirs("/home/workspace/logs", exist_ok=True)
        os.makedirs("/home/workspace/data/raw_articles", exist_ok=True)
        os.makedirs("/home/workspace/data/parsed_funding", exist_ok=True)
        
    def _init_database(self):
        """初始化SQLite数据库"""
        db_path = "/home/workspace/data/wechat_funding.db"
        self.db_conn = sqlite3.connect(db_path)
        
        # 创建文章表
        self.db_conn.execute('''
            CREATE TABLE IF NOT EXISTS articles (
                article_id TEXT PRIMARY KEY,
                account_name TEXT,
                title TEXT,
                content TEXT,
                url TEXT,
                publish_time TEXT,
                crawl_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建融资信息表
        self.db_conn.execute('''
            CREATE TABLE IF NOT EXISTS funding_info (
                funding_id TEXT PRIMARY KEY,
                article_id TEXT,
                company_name TEXT,
                funding_amount TEXT,
                funding_round TEXT,
                investors TEXT,
                industry TEXT,
                extraction_confidence REAL,
                source_article TEXT,
                source_account TEXT,
                publish_date TEXT,
                article_url TEXT,
                extraction_timestamp TIMESTAMP,
                raw_sentence TEXT,
                FOREIGN KEY (article_id) REFERENCES articles (article_id)
            )
        ''')
        
        # 创建索引
        self.db_conn.execute('CREATE INDEX IF NOT EXISTS idx_company ON funding_info(company_name)')
        self.db_conn.execute('CREATE INDEX IF NOT EXISTS idx_date ON funding_info(publish_date)')
        self.db_conn.execute('CREATE INDEX IF NOT EXISTS idx_confidence ON funding_info(extraction_confidence)')
        
        self.db_conn.commit()
    
    def simulate_crawl(self, account_name: str, days_back: int = 1) -> List[WeChatArticle]:
        """
        模拟抓取公众号文章
        
        在实际部署中，这里会替换为真实的公众号抓取逻辑
        目前使用模拟数据来演示流程
        """
        logger.info(f"开始模拟抓取公众号: {account_name}")
        
        # 模拟不同公众号的文章内容
        simulated_articles = self._generate_simulated_articles(account_name, days_back)
        
        articles = []
        for sim_article in simulated_articles:
            article = WeChatArticle(
                account_name=account_name,
                title=sim_article["title"],
                content=sim_article["content"],
                url=sim_article["url"],
                publish_time=sim_article["publish_time"]
            )
            
            # 保存到数据库
            self._save_article_to_db(article)
            
            # 保存原始内容到文件
            self._save_raw_article(article)
            
            articles.append(article)
            
            logger.info(f"模拟抓取文章: {article.title}")
            
        return articles
    
    def _generate_simulated_articles(self, account_name: str, days_back: int) -> List[Dict]:
        """生成模拟的公众号文章"""
        
        base_time = datetime.now() - timedelta(days=days_back)
        
        if account_name == "Strictly VC":
            return [
                {
                    "title": "AI Startup NeuralMind Raises $50M Series B Led by Sequoia",
                    "content": """NeuralMind, an artificial intelligence company specializing in large language models, has raised $50 million in a Series B funding round. The round was led by Sequoia Capital with participation from Andreessen Horowitz and existing investor Lightspeed Venture Partners.

The company plans to use the funds to expand its research team and accelerate development of its proprietary AI models. NeuralMind's CEO, Dr. Alex Chen, stated that the company is focused on creating more efficient and accessible AI systems.

Founded in 2024, NeuralMind has now raised a total of $85 million. The company's technology is being used by several enterprise customers for natural language processing tasks.""",
                    "url": "https://example.com/strictlyvc/neuralmind-50m",
                    "publish_time": base_time.strftime("%Y-%m-%d %H:%M:%S")
                },
                {
                    "title": "Quantum Computing Startup QubitTech Secures $30M in Series A",
                    "content": """QubitTech, a quantum computing hardware company, has secured $30 million in Series A funding. The investment was led by Founders Fund with participation from DCVC and strategic corporate investors.

The funding will be used to build out the company's quantum processor manufacturing facilities. QubitTech is developing error-corrected quantum processors that could revolutionize fields like drug discovery and materials science.

CEO Dr. Sarah Johnson emphasized the long-term nature of quantum computing development, noting that this funding provides runway for the next critical phase of research and development.""",
                    "url": "https://example.com/strictlyvc/qubittech-30m",
                    "publish_time": (base_time - timedelta(hours=3)).strftime("%Y-%m-%d %H:%M:%S")
                }
            ]
        
        elif account_name == "36氪Pro":
            return [
                {
                    "title": "自动驾驶公司智驾科技完成10亿元C轮融资",
                    "content": """国内自动驾驶解决方案提供商智驾科技今日宣布完成10亿元人民币C轮融资。本轮融资由红杉中国领投，高瓴资本、源码资本跟投。

智驾科技成立于2022年，专注于L4级自动驾驶技术的研发和商业化落地。公司已经与多家主机厂达成合作，计划在未来两年内实现量产。

创始人兼CEO李伟表示，本轮融资将主要用于技术研发、团队扩张和商业化落地。截至目前，智驾科技累计融资额已超过20亿元。""",
                    "url": "https://example.com/36kr/zhijia-1b",
                    "publish_time": base_time.strftime("%Y-%m-%d %H:%M:%S")
                },
                {
                    "title": "医疗AI公司深睿医疗完成5亿元B+轮融资",
                    "content": """人工智能医疗影像公司深睿医疗近日宣布完成5亿元人民币B+轮融资。本轮融资由启明创投领投，华兴资本、中金资本等跟投。

深睿医疗专注于医疗影像AI辅助诊断系统，产品已在全国超过500家医院落地应用。公司计划将本轮融资用于产品线扩展和国际市场开拓。

公司联合创始人王海表示，随着AI在医疗领域的深入应用，深睿医疗将继续加大研发投入，推动医疗AI技术的普惠化。""",
                    "url": "https://example.com/36kr/shenrui-500m",
                    "publish_time": (base_time - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S")
                }
            ]
        
        else:
            # 默认模拟文章
            return [
                {
                    "title": f"{account_name} 最新融资动态",
                    "content": f"这是{account_name}的模拟文章内容，包含一些融资信息。例如：某科技公司完成5000万元A轮融资，投资方包括多家知名机构。",
                    "url": f"https://example.com/{account_name}/latest",
                    "publish_time": base_time.strftime("%Y-%m-%d %H:%M:%S")
                }
            ]
    
    def _save_article_to_db(self, article: WeChatArticle):
        """保存文章到数据库"""
        try:
            cursor = self.db_conn.cursor()
            cursor.execute('''
                INSERT OR IGNORE INTO articles 
                (article_id, account_name, title, content, url, publish_time)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                article.article_id,
                article.account_name,
                article.title,
                article.content,
                article.url,
                article.publish_time
            ))
            self.db_conn.commit()
        except Exception as e:
            logger.error(f"保存文章到数据库失败: {e}")
    
    def _save_raw_article(self, article: WeChatArticle):
        """保存原始文章内容到文件"""
        try:
            filename = f"{article.article_id}.json"
            filepath = f"/home/workspace/data/raw_articles/{filename}"
            
            article_data = {
                "article_id": article.article_id,
                "account_name": article.account_name,
                "title": article.title,
                "full_content": article.content,
                "url": article.url,
                "publish_time": article.publish_time,
                "save_timestamp": datetime.now().isoformat()
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(article_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"保存原始文章失败: {e}")
    
    def crawl_and_parse(self, days_back: int = 1) -> Dict[str, List[Dict]]:
        """
        执行完整的抓取和解析流程
        
        返回: 按公众号分类的融资信息
        """
        logger.info("开始执行公众号抓取和解析流程")
        
        all_funding_info = {}
        total_funding_count = 0
        
        for account in self.config["wechat_accounts"]:
            account_name = account["name"]
            
            try:
                # 模拟抓取文章
                articles = self.simulate_crawl(account_name, days_back)
                
                account_funding = []
                for article in articles:
                    # 提取融资信息
                    funding_infos = self.extractor.extract_funding_info(article)
                    
                    for funding_info in funding_infos:
                        # 保存融资信息到数据库
                        self._save_funding_to_db(funding_info, article.article_id)
                        
                        # 保存到文件
                        self._save_funding_to_file(funding_info)
                        
                        account_funding.append(funding_info)
                        total_funding_count += 1
                
                if account_funding:
                    all_funding_info[account_name] = account_funding
                    logger.info(f"{account_name}: 提取到 {len(account_funding)} 条融资信息")
                    
            except Exception as e:
                logger.error(f"处理公众号 {account_name} 时出错: {e}")
                continue
        
        logger.info(f"流程完成，共提取到 {total_funding_count} 条融资信息")
        return all_funding_info
    
    def _save_funding_to_db(self, funding_info: Dict, article_id: str):
        """保存融资信息到数据库"""
        try:
            # 生成融资信息ID
            funding_id = hashlib.md5(
                f"{funding_info['company_name']}_{funding_info['funding_amount']}_{funding_info['publish_date']}".encode()
            ).hexdigest()[:12]
            
            cursor = self.db_conn.cursor()
            cursor.execute('''
                INSERT OR IGNORE INTO funding_info 
                (funding_id, article_id, company_name, funding_amount, funding_round, 
                 investors, industry, extraction_confidence, source_article, 
                 source_account, publish_date, article_url, extraction_timestamp, raw_sentence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                funding_id,
                article_id,
                funding_info["company_name"],
                funding_info["funding_amount"],
                funding_info["funding_round"],
                json.dumps(funding_info["investors"], ensure_ascii=False),
                funding_info["industry"],
                funding_info["extraction_confidence"],
                funding_info["source_article"],
                funding_info["source_account"],
                funding_info["publish_date"],
                funding_info["article_url"],
                funding_info["extraction_timestamp"],
                funding_info["raw_sentence"]
            ))
            self.db_conn.commit()
            
        except Exception as e:
            logger.error(f"保存融资信息到数据库失败: {e}")
    
    def _save_funding_to_file(self, funding_info: Dict):
        """保存融资信息到文件"""
        try:
            # 按日期组织文件
            publish_date = funding_info["publish_date"][:10]  # 取YYYY-MM-DD部分
            filename = f"{publish_date}.json"
            filepath = f"/home/workspace/data/parsed_funding/{filename}"
            
            # 读取现有数据或创建新文件
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
            else:
                existing_data = []
            
            # 添加新数据
            existing_data.append(funding_info)
            
            # 保存文件
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(existing_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"保存融资信息到文件失败: {e}")
    
    def generate_daily_report(self) -> Dict:
        """生成每日报告"""
        try:
            # 获取今天的数据
            today = datetime.now().strftime("%Y-%m-%d")
            cursor = self.db_conn.cursor()
            
            # 统计今天的数据
            cursor.execute('''
                SELECT 
                    COUNT(DISTINCT article_id) as article_count,
                    COUNT(DISTINCT funding_id) as funding_count,
                    COUNT(DISTINCT company_name) as company_count,
                    AVG(extraction_confidence) as avg_confidence
                FROM funding_info 
                WHERE DATE(publish_date) = ?
            ''', (today,))
            
            stats = cursor.fetchone()
            
            # 获取今天的融资信息详情
            cursor.execute('''
                SELECT company_name, funding_amount, funding_round, industry, 
                       extraction_confidence, source_account
                FROM funding_info 
                WHERE DATE(publish_date) = ?
                ORDER BY extraction_confidence DESC
                LIMIT 20
            ''', (today,))
            
            funding_details = cursor.fetchall()
            
            # 按行业统计
            cursor.execute('''
                SELECT industry, COUNT(*) as count
                FROM funding_info 
                WHERE DATE(publish_date) = ?
                GROUP BY industry
                ORDER BY count DESC
            ''', (today,))
            
            industry_stats = cursor.fetchall()
            
            # 构建报告
            report = {
                "report_date": today,
                "generation_time": datetime.now().isoformat(),
                "summary": {
                    "articles_processed": stats[0] if stats else 0,
                    "funding_events_found": stats[1] if stats else 0,
                    "unique_companies": stats[2] if stats else 0,
                    "average_confidence": round(stats[3], 3) if stats and stats[3] else 0
                },
                "top_funding_events": [
                    {
                        "company": row[0],
                        "amount": row[1],
                        "round": row[2],
                        "industry": row[3],
                        "confidence": round(row[4], 3),
                        "source": row[5]
                    }
                    for row in funding_details
                ],
                "industry_distribution": [
                    {"industry": row[0], "count": row[1]}
                    for row in industry_stats
                ],
                "data_quality": {
                    "high_confidence_events": len([row for row in funding_details if row[4] >= 0.8]),
                    "medium_confidence_events": len([row for row in funding_details if 0.6 <= row[4] < 0.8]),
                    "low_confidence_events": len([row for row in funding_details if row[4] < 0.6])
                }
            }
            
            # 保存报告
            report_file = f"/home/workspace/data/daily_report_{today}.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            logger.info(f"生成每日报告: {report_file}")
            return report
            
        except Exception as e:
            logger.error(f"生成每日报告失败: {e}")
            return {"error": str(e)}
    
    def close(self):
        """关闭数据库连接"""
        if self.db_conn:
            self.db_conn.close()

def main():
    """主函数 - 演示完整流程"""
    print("=== 微信公众号融资信息监控系统 ===")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 创建爬虫实例
    crawler = WeChatCrawler()
    
    try:
        print("\n1. 开始抓取和解析公众号内容...")
        
        # 执行抓取和解析
        funding_data = crawler.crawl_and_parse(days_back=1)
        
        print(f"\n2. 抓取完成，共处理 {len(funding_data)} 个公众号")
        
        # 生成报告
        print("\n3. 生成每日报告...")
        report = crawler.generate_daily_report()
        
        if "error" not in report:
            print(f"报告生成成功!")
            print(f"- 处理文章: {report['summary']['articles_processed']}")
            print(f"- 发现融资事件: {report['summary']['funding_events_found']}")
            print(f"- 涉及公司: {report['summary']['unique_companies']}")
            print(f"- 平均置信度: {report['summary']['average_confidence']:.3f}")
            
            # 显示部分高置信度事件
            print("\n高置信度融资事件 (置信度 >= 0.8):")
            top_events = [e for e in report['top_funding_events'] if e['confidence'] >= 0.8]
            for i, event in enumerate(top_events[:5], 1):
                print(f"  {i}. {event['company']} - {event['amount']} ({event['round']})")
        
        # 保存汇总数据
        output_file = "/home/workspace/today_funding_summary.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                "extraction_date": datetime.now().strftime("%Y-%m-%d"),
                "funding_data": funding_data,
                "report_summary": report.get('summary', {})
            }, f, ensure_ascii=False, indent=2)
        
        print(f"\n4. 数据已保存到: {output_file}")
        
    except Exception as e:
        print(f"执行过程中出错: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        crawler.close()
    
    print(f"\n=== 流程完成于: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")

if __name__ == "__main__":
    main()