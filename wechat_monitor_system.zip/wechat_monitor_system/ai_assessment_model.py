#!/usr/bin/env python3
"""
AI评估模型与follow/not决策系统

功能：
1. 基于公众号抓取的融资信息进行深度分析
2. 多维度量化评估
3. 智能follow/not决策
4. 与飞书表格集成
"""

import json
import re
import os
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import requests
from enum import Enum

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/workspace/logs/ai_assessment.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DecisionType(Enum):
    """决策类型枚举"""
    STRONG_FOLLOW = "强烈关注"        # 综合评分 >= 80
    FOLLOW = "建议关注"               # 综合评分 >= 70
    WATCH = "保持观察"                # 综合评分 >= 60
    NOT_FOLLOW = "暂不关注"           # 综合评分 < 60

class AssessmentFactor(Enum):
    """评估维度枚举"""
    MARKET_OPPORTUNITY = "市场机会"     # 权重: 0.25
    TECHNOLOGY_STRENGTH = "技术实力"    # 权重: 0.20
    BUSINESS_MODEL = "商业模式"         # 权重: 0.20
    TEAM_BACKGROUND = "团队背景"        # 权重: 0.15
    FUNDING_SITUATION = "融资情况"      # 权重: 0.10
    RISK_FACTORS = "风险因素"           # 权重: 0.10

class CompanyAssessment:
    """公司评估类"""
    
    def __init__(self, config_path: str = "/home/workspace/wechat_config.json"):
        """初始化评估器"""
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # 评估维度权重
        self.weights = {
            AssessmentFactor.MARKET_OPPORTUNITY: 0.25,
            AssessmentFactor.TECHNOLOGY_STRENGTH: 0.20,
            AssessmentFactor.BUSINESS_MODEL: 0.20,
            AssessmentFactor.TEAM_BACKGROUND: 0.15,
            AssessmentFactor.FUNDING_SITUATION: 0.10,
            AssessmentFactor.RISK_FACTORS: 0.10
        }
        
        # 子维度定义
        self.sub_dimensions = {
            AssessmentFactor.MARKET_OPPORTUNITY: [
                "市场规模", "增长潜力", "竞争格局", "政策环境"
            ],
            AssessmentFactor.TECHNOLOGY_STRENGTH: [
                "技术壁垒", "创新能力", "专利情况", "团队背景"
            ],
            AssessmentFactor.BUSINESS_MODEL: [
                "盈利模式", "客户获取", "单位经济", "扩展性"
            ],
            AssessmentFactor.TEAM_BACKGROUND: [
                "创始人经验", "团队完整性", "执行能力", "行业资源"
            ],
            AssessmentFactor.FUNDING_SITUATION: [
                "估值合理性", "投资方背景", "资金用途", "历史融资"
            ],
            AssessmentFactor.RISK_FACTORS: [
                "监管风险", "技术风险", "市场风险", "竞争风险"
            ]
        }
        
        # 行业热力图 (基于2026年市场趋势)
        self.industry_hotness = {
            "人工智能": 0.95,
            "量子计算": 0.90,
            "新能源": 0.85,
            "生物医药": 0.88,
            "半导体": 0.92,
            "企业服务": 0.80,
            "消费科技": 0.75,
            "金融科技": 0.82,
            "教育科技": 0.70,
            "医疗健康": 0.85,
            "智能制造": 0.83,
            "新材料": 0.78
        }
        
        # 顶级投资机构列表
        self.top_investors = {
            "国际": ["Sequoia", "Andreessen Horowitz", "Accel", "Benchmark", "Tiger Global"],
            "国内": ["红杉中国", "高瓴资本", "启明创投", "IDG资本", "源码资本", "今日资本"]
        }
        
        # 明星团队背景关键词
        self.star_team_keywords = [
            "前Google", "前Facebook", "前微软", "前阿里", "前腾讯", "前字节跳动",
            "斯坦福", "麻省理工", "哈佛", "清华", "北大", "博士", "教授"
        ]
    
    def assess_company(self, funding_info: Dict, 
                       additional_data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        对公司进行综合评估
        
        参数:
            funding_info: 从公众号提取的融资信息
            additional_data: 额外的公司信息（来自网络搜索等）
        
        返回: 完整的评估报告
        """
        logger.info(f"开始评估公司: {funding_info.get('company_name', '未知公司')}")
        
        # 基础信息
        company_name = funding_info.get('company_name', '')
        industry = funding_info.get('industry', '未分类')
        funding_amount = funding_info.get('funding_amount', '')
        funding_round = funding_info.get('funding_round', '未明确')
        investors = funding_info.get('investors', [])
        
        # 收集所有可用信息
        all_data = {
            "funding_info": funding_info,
            "additional_data": additional_data or {},
            "extracted_features": self._extract_features(funding_info, additional_data)
        }
        
        # 各维度评分
        dimension_scores = {}
        detailed_scores = {}
        
        for factor in AssessmentFactor:
            factor_score, sub_scores = self._score_dimension(factor, all_data)
            dimension_scores[factor.value] = factor_score
            detailed_scores[factor.value] = sub_scores
        
        # 计算综合评分（0-10分制）
        comprehensive_score_10 = self._calculate_comprehensive_score(dimension_scores)
        
        # 转换为0-100分制
        comprehensive_score_100 = comprehensive_score_10 * 10
        
        # 特殊规则加分（按比例调整到0-100分制）
        bonus_points_10 = self._calculate_bonus_points(all_data)
        bonus_points_100 = bonus_points_10 * 10
        
        final_score = comprehensive_score_100 + bonus_points_100
        
        # 决策判断
        decision, confidence = self._make_decision(final_score, dimension_scores, all_data)
        
        # 生成评估报告
        report = {
            "company_name": company_name,
            "assessment_date": datetime.now().isoformat(),
            "industry": industry,
            "funding_info": {
                "amount": funding_amount,
                "round": funding_round,
                "investors": investors,
                "source": funding_info.get('source_account', '')
            },
            "scores": {
                "dimension_scores": dimension_scores,
                "detailed_scores": detailed_scores,
                "comprehensive_score_10": round(comprehensive_score_10, 2),
                "comprehensive_score_100": round(comprehensive_score_100, 2),
                "bonus_points_10": round(bonus_points_10, 2),
                "bonus_points_100": round(bonus_points_100, 2),
                "final_score": round(final_score, 2)
            },
            "decision": {
                "type": decision.value,
                "confidence": round(confidence, 3),
                "reasoning": self._generate_decision_reasoning(decision, final_score, dimension_scores),
                "next_steps": self._suggest_next_steps(decision, all_data)
            },
            "key_findings": self._extract_key_findings(dimension_scores, all_data),
            "risk_analysis": self._analyze_risks(dimension_scores),
            "data_quality": {
                "funding_info_quality": self._assess_data_quality(funding_info),
                "additional_data_quality": self._assess_data_quality(additional_data) if additional_data else 0,
                "overall_confidence": self._calculate_overall_confidence(funding_info, additional_data)
            }
        }
        
        logger.info(f"评估完成: {company_name} - {decision.value} (分数: {final_score:.2f})")
        return report
    
    def _extract_features(self, funding_info: Dict, additional_data: Optional[Dict]) -> Dict:
        """从数据中提取特征"""
        features = {}
        
        # 从融资信息提取特征
        company_name = funding_info.get('company_name', '')
        industry = funding_info.get('industry', '未分类')
        funding_amount = funding_info.get('funding_amount', '')
        funding_round = funding_info.get('funding_round', '')
        investors = funding_info.get('investors', [])
        
        # 融资金额特征
        features["funding_amount_numeric"] = self._parse_funding_amount(funding_amount)
        features["funding_round_numeric"] = self._parse_funding_round(funding_round)
        
        # 投资方特征
        features["has_top_investors"] = self._has_top_investors(investors)
        features["investor_count"] = len(investors)
        features["investor_quality_score"] = self._score_investor_quality(investors)
        
        # 行业特征
        features["industry_hotness"] = self.industry_hotness.get(industry, 0.5)
        features["is_hot_industry"] = features["industry_hotness"] >= 0.8
        
        # 从附加数据提取特征（如果可用）
        if additional_data:
            # 公司规模特征
            features["company_size"] = additional_data.get('employee_count', 0)
            features["founded_year"] = additional_data.get('founded_year', 0)
            features["company_age"] = datetime.now().year - features["founded_year"] if features["founded_year"] > 0 else 0
            
            # 团队特征
            team_desc = additional_data.get('team_description', '')
            features["has_star_team"] = any(keyword in team_desc for keyword in self.star_team_keywords)
            features["team_background_score"] = self._score_team_background_simple(team_desc)
            
            # 技术特征
            tech_desc = additional_data.get('technology_description', '')
            features["tech_sophistication_score"] = self._score_tech_sophistication(tech_desc)
            features["patent_count"] = additional_data.get('patent_count', 0)
        
        return features
    
    def _score_dimension(self, factor: AssessmentFactor, data: Dict) -> Tuple[float, Dict]:
        """评分单个维度"""
        features = data["extracted_features"]
        
        if factor == AssessmentFactor.MARKET_OPPORTUNITY:
            return self._score_market_opportunity(features)
        elif factor == AssessmentFactor.TECHNOLOGY_STRENGTH:
            return self._score_technology_strength(features)
        elif factor == AssessmentFactor.BUSINESS_MODEL:
            return self._score_business_model(features)
        elif factor == AssessmentFactor.TEAM_BACKGROUND:
            return self._score_team_background(features)
        elif factor == AssessmentFactor.FUNDING_SITUATION:
            return self._score_funding_situation(features)
        elif factor == AssessmentFactor.RISK_FACTORS:
            return self._score_risk_factors(features)
        else:
            return 5.0, {"未评估": 5.0}  # 默认分数
    
    def _score_market_opportunity(self, features: Dict) -> Tuple[float, Dict]:
        """评分市场机会维度"""
        sub_scores = {}
        
        # 1. 市场规模
        industry_hotness = features.get("industry_hotness", 0.5)
        sub_scores["市场规模"] = industry_hotness * 10  # 转换为0-10分
        
        # 2. 增长潜力（基于行业热度和融资轮次）
        is_hot = features.get("is_hot_industry", False)
        funding_round_numeric = features.get("funding_round_numeric", 0)
        
        if is_hot and funding_round_numeric <= 3:  # 早期阶段+热门赛道
            growth_score = 9.0
        elif is_hot:
            growth_score = 7.5
        elif funding_round_numeric <= 3:
            growth_score = 6.5
        else:
            growth_score = 5.0
        sub_scores["增长潜力"] = growth_score
        
        # 3. 竞争格局
        # 假设早期阶段竞争相对较小
        if funding_round_numeric <= 2:
            competition_score = 8.0
        elif funding_round_numeric <= 4:
            competition_score = 6.5
        else:
            competition_score = 5.0
        sub_scores["竞争格局"] = competition_score
        
        # 4. 政策环境
        industry = features.get("industry", "")
        policy_support_industries = ["新能源", "半导体", "生物医药", "人工智能"]
        if industry in policy_support_industries:
            policy_score = 8.5
        else:
            policy_score = 6.0
        sub_scores["政策环境"] = policy_score
        
        # 计算维度总分（子维度平均分）
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _score_technology_strength(self, features: Dict) -> Tuple[float, Dict]:
        """评分技术实力维度"""
        sub_scores = {}
        
        # 1. 技术壁垒
        tech_score = features.get("tech_sophistication_score", 5.0)
        sub_scores["技术壁垒"] = tech_score
        
        # 2. 创新能力
        # 基于融资轮次推断创新能力
        funding_round_numeric = features.get("funding_round_numeric", 0)
        if funding_round_numeric <= 2:  # 早期阶段通常有更高创新性
            innovation_score = 8.0
        elif funding_round_numeric <= 4:
            innovation_score = 6.5
        else:
            innovation_score = 5.5
        sub_scores["创新能力"] = innovation_score
        
        # 3. 专利情况
        patent_count = features.get("patent_count", 0)
        if patent_count >= 10:
            patent_score = 9.0
        elif patent_count >= 5:
            patent_score = 7.5
        elif patent_count >= 1:
            patent_score = 6.0
        else:
            patent_score = 4.0
        sub_scores["专利情况"] = patent_score
        
        # 4. 团队技术背景
        team_score = features.get("team_background_score", 5.0)
        sub_scores["团队背景"] = team_score
        
        # 计算维度总分
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _score_business_model(self, features: Dict) -> Tuple[float, Dict]:
        """评分商业模式维度"""
        sub_scores = {}
        
        # 1. 盈利模式
        # 基于融资轮次推断盈利模式成熟度
        funding_round_numeric = features.get("funding_round_numeric", 0)
        if funding_round_numeric >= 4:  # C轮及以后应该有明确盈利模式
            revenue_score = 8.0
        elif funding_round_numeric >= 2:
            revenue_score = 6.5
        else:
            revenue_score = 5.0
        sub_scores["盈利模式"] = revenue_score
        
        # 2. 客户获取
        # 有顶级投资机构可能意味着有客户资源
        has_top_investors = features.get("has_top_investors", False)
        if has_top_investors:
            customer_score = 8.0
        else:
            customer_score = 5.5
        sub_scores["客户获取"] = customer_score
        
        # 3. 单位经济
        # 早期阶段难以评估，给中等分数
        unit_economics_score = 6.0
        sub_scores["单位经济"] = unit_economics_score
        
        # 4. 扩展性
        industry_hotness = features.get("industry_hotness", 0.5)
        scalability_score = industry_hotness * 8 + 2  # 转换为2-10分
        sub_scores["扩展性"] = scalability_score
        
        # 计算维度总分
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _score_team_background(self, features: Dict) -> Tuple[float, Dict]:
        """评分团队背景维度"""
        sub_scores = {}
        
        # 1. 创始人经验
        has_star_team = features.get("has_star_team", False)
        if has_star_team:
            founder_score = 9.0
        else:
            founder_score = 6.0
        sub_scores["创始人经验"] = founder_score
        
        # 2. 团队完整性
        # 基于融资轮次推断团队完整性
        funding_round_numeric = features.get("funding_round_numeric", 0)
        if funding_round_numeric >= 3:
            team_complete_score = 8.0
        elif funding_round_numeric >= 1:
            team_complete_score = 6.5
        else:
            team_complete_score = 5.0
        sub_scores["团队完整性"] = team_complete_score
        
        # 3. 执行能力
        # 有多次融资通常意味着执行能力较强
        if funding_round_numeric >= 2:
            execution_score = 7.5
        else:
            execution_score = 5.5
        sub_scores["执行能力"] = execution_score
        
        # 4. 行业资源
        has_top_investors = features.get("has_top_investors", False)
        investor_quality = features.get("investor_quality_score", 5.0)
        resource_score = (investor_quality / 10) * 8 + 2  # 转换为2-10分
        sub_scores["行业资源"] = resource_score
        
        # 计算维度总分
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _score_funding_situation(self, features: Dict) -> Tuple[float, Dict]:
        """评分融资情况维度"""
        sub_scores = {}
        
        # 1. 估值合理性
        funding_amount = features.get("funding_amount_numeric", 0)
        funding_round_numeric = features.get("funding_round_numeric", 0)
        
        # 简单估值合理性判断
        if funding_amount > 0 and funding_round_numeric > 0:
            # 计算每轮平均融资增长
            avg_funding_per_round = funding_amount / funding_round_numeric
            if 1 <= avg_funding_per_round <= 100:  # 百万到亿级别
                valuation_score = 8.0
            else:
                valuation_score = 6.0
        else:
            valuation_score = 5.0
        sub_scores["估值合理性"] = valuation_score
        
        # 2. 投资方背景
        investor_quality = features.get("investor_quality_score", 5.0)
        sub_scores["投资方背景"] = investor_quality
        
        # 3. 资金用途
        # 早期融资通常用于研发和扩张
        if funding_round_numeric <= 3:
            usage_score = 7.5  # 早期融资用途明确
        else:
            usage_score = 6.0  # 后期融资用途可能更复杂
        sub_scores["资金用途"] = usage_score
        
        # 4. 历史融资
        if funding_round_numeric >= 2:
            history_score = 8.0  # 有多次融资记录
        elif funding_round_numeric == 1:
            history_score = 6.5  # 首次融资
        else:
            history_score = 5.0  # 无融资信息
        sub_scores["历史融资"] = history_score
        
        # 计算维度总分
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _score_risk_factors(self, features: Dict) -> Tuple[float, Dict]:
        """评分风险因素维度"""
        sub_scores = {}
        
        # 1. 监管风险
        industry = features.get("industry", "")
        high_reg_risk_industries = ["金融科技", "医疗健康", "教育科技"]
        if industry in high_reg_risk_industries:
            reg_risk_score = 3.0  # 高风险，低分
        else:
            reg_risk_score = 7.0  # 低风险，高分
        sub_scores["监管风险"] = reg_risk_score
        
        # 2. 技术风险
        tech_score = features.get("tech_sophistication_score", 5.0)
        # 技术越成熟，风险越低
        tech_risk_score = max(3.0, 10 - tech_score)  # 转换为风险分数
        sub_scores["技术风险"] = tech_risk_score
        
        # 3. 市场风险
        industry_hotness = features.get("industry_hotness", 0.5)
        # 过热行业可能有泡沫风险
        if industry_hotness >= 0.9:
            market_risk_score = 4.0  # 高风险
        elif industry_hotness >= 0.7:
            market_risk_score = 6.0  # 中等风险
        else:
            market_risk_score = 8.0  # 低风险
        sub_scores["市场风险"] = market_risk_score
        
        # 4. 竞争风险
        funding_round_numeric = features.get("funding_round_numeric", 0)
        # 早期阶段竞争风险较低，后期较高
        if funding_round_numeric >= 4:
            competition_risk_score = 4.0  # 高风险
        elif funding_round_numeric >= 2:
            competition_risk_score = 6.0  # 中等风险
        else:
            competition_risk_score = 8.0  # 低风险
        sub_scores["竞争风险"] = competition_risk_score
        
        # 计算维度总分（风险分数越高越好，表示风险越低）
        dimension_score = sum(sub_scores.values()) / len(sub_scores)
        
        return round(dimension_score, 2), sub_scores
    
    def _calculate_comprehensive_score(self, dimension_scores: Dict) -> float:
        """计算加权综合评分（0-10分制）"""
        total_score = 0.0
        total_weight = 0.0
        
        for factor in AssessmentFactor:
            if factor.value in dimension_scores:
                total_score += dimension_scores[factor.value] * self.weights[factor]
                total_weight += self.weights[factor]
        
        if total_weight > 0:
            return total_score / total_weight
        return 0.0
    
    def _calculate_bonus_points(self, data: Dict) -> float:
        """计算特殊规则加分"""
        features = data["extracted_features"]
        bonus = 0.0
        
        # 1. 顶级投资机构参与
        if features.get("has_top_investors", False):
            bonus += 5.0
        
        # 2. 热门赛道
        if features.get("is_hot_industry", False):
            bonus += 3.0
        
        # 3. 明星团队背景
        if features.get("has_star_team", False):
            bonus += 5.0
        
        # 4. 融资轮次过早（风险较高）
        funding_round_numeric = features.get("funding_round_numeric", 0)
        if funding_round_numeric <= 1:  # 种子/天使轮
            bonus -= 5.0
        
        return bonus
    
    def _make_decision(self, final_score: float, dimension_scores: Dict, data: Dict) -> Tuple[DecisionType, float]:
        """做出follow/not决策"""
        
        # 基础决策规则
        if final_score >= 80:
            decision = DecisionType.STRONG_FOLLOW
        elif final_score >= 70:
            decision = DecisionType.FOLLOW
        elif final_score >= 60:
            decision = DecisionType.WATCH
        else:
            decision = DecisionType.NOT_FOLLOW
        
        # 计算决策置信度
        confidence = self._calculate_decision_confidence(final_score, dimension_scores, data)
        
        return decision, confidence
    
    def _calculate_decision_confidence(self, final_score: float, dimension_scores: Dict, data: Dict) -> float:
        """计算决策置信度"""
        confidence = 0.7  # 基础置信度
        
        # 1. 分数离决策边界越远，置信度越高
        if final_score >= 80:
            distance = final_score - 80
        elif final_score >= 70:
            distance = min(final_score - 70, 80 - final_score)
        elif final_score >= 60:
            distance = min(final_score - 60, 70 - final_score)
        else:
            distance = 60 - final_score
        
        confidence += min(distance * 0.02, 0.2)  # 最多增加0.2
        
        # 2. 数据完整度影响置信度
        data_quality = data.get("extracted_features", {}).get("data_completeness", 0.5)
        confidence += (data_quality - 0.5) * 0.3  # 最多调整0.15
        
        # 3. 各维度分数一致性
        scores = list(dimension_scores.values())
        if scores:
            std_dev = (max(scores) - min(scores)) / 10
            consistency_factor = 1.0 - std_dev
            confidence *= consistency_factor
        
        return max(0.1, min(1.0, confidence))  # 限制在0.1-1.0之间
    
    def _generate_decision_reasoning(self, decision: DecisionType, final_score: float, 
                                    dimension_scores: Dict) -> str:
        """生成决策理由"""
        
        reason_parts = []
        
        # 分数描述
        if final_score >= 80:
            reason_parts.append("综合评分表现优异")
        elif final_score >= 70:
            reason_parts.append("综合评分表现良好")
        elif final_score >= 60:
            reason_parts.append("综合评分表现一般")
        else:
            reason_parts.append("综合评分表现不佳")
        
        # 突出优势维度
        top_dimensions = sorted(dimension_scores.items(), key=lambda x: x[1], reverse=True)[:2]
        for dimension, score in top_dimensions:
            if score >= 8.0:
                reason_parts.append(f"{dimension}表现突出")
        
        # 明显劣势维度
        bottom_dimensions = sorted(dimension_scores.items(), key=lambda x: x[1])[:1]
        for dimension, score in bottom_dimensions:
            if score <= 4.0:
                reason_parts.append(f"{dimension}有待加强")
        
        return "；".join(reason_parts)
    
    def _suggest_next_steps(self, decision: DecisionType, data: Dict) -> List[str]:
        """建议下一步行动"""
        steps = []
        
        if decision == DecisionType.STRONG_FOLLOW:
            steps.extend([
                "立即安排团队对接会议",
                "深入进行尽职调查",
                "评估投资条款和估值",
                "制定投资时间表"
            ])
        elif decision == DecisionType.FOLLOW:
            steps.extend([
                "安排初步接触会议",
                "收集更多公司信息",
                "观察后续发展动态",
                "定期评估更新"
            ])
        elif decision == DecisionType.WATCH:
            steps.extend([
                "关注公司后续融资进展",
                "跟踪产品/技术发展",
                "观察市场接受度变化",
                "季度评估更新"
            ])
        else:  # NOT_FOLLOW
            steps.extend([
                "记录评估结果供参考",
                "关注类似赛道其他机会",
                "如情况变化可重新评估"
            ])
        
        return steps
    
    def _extract_key_findings(self, dimension_scores: Dict, data: Dict) -> List[str]:
        """提取关键发现"""
        findings = []
        
        # 最高分维度
        max_dimension = max(dimension_scores.items(), key=lambda x: x[1])
        if max_dimension[1] >= 8.0:
            findings.append(f"核心优势：{max_dimension[0]}（得分：{max_dimension[1]:.1f}）")
        
        # 最低分维度
        min_dimension = min(dimension_scores.items(), key=lambda x: x[1])
        if min_dimension[1] <= 4.0:
            findings.append(f"主要短板：{min_dimension[0]}（得分：{min_dimension[1]:.1f}）")
        
        # 特殊特征
        features = data.get("extracted_features", {})
        if features.get("has_top_investors", False):
            findings.append("获得顶级投资机构背书")
        
        if features.get("has_star_team", False):
            findings.append("拥有明星团队背景")
        
        if features.get("is_hot_industry", False):
            findings.append("处于热门投资赛道")
        
        return findings
    
    def _analyze_risks(self, dimension_scores: Dict) -> Dict:
        """分析风险"""
        risks = {}
        
        # 技术风险
        tech_score = dimension_scores.get(AssessmentFactor.TECHNOLOGY_STRENGTH.value, 5.0)
        if tech_score <= 4.0:
            risks["技术风险"] = "高 - 技术实力不足可能影响产品竞争力"
        elif tech_score <= 6.0:
            risks["技术风险"] = "中 - 技术实力一般，需持续关注发展"
        else:
            risks["技术风险"] = "低 - 技术实力较强"
        
        # 市场风险
        market_score = dimension_scores.get(AssessmentFactor.MARKET_OPPORTUNITY.value, 5.0)
        if market_score <= 4.0:
            risks["市场风险"] = "高 - 市场机会有限或竞争激烈"
        elif market_score <= 6.0:
            risks["市场风险"] = "中 - 市场机会一般，需进一步验证"
        else:
            risks["市场风险"] = "低 - 市场机会良好"
        
        # 融资风险
        funding_score = dimension_scores.get(AssessmentFactor.FUNDING_SITUATION.value, 5.0)
        if funding_score <= 4.0:
            risks["融资风险"] = "高 - 融资情况不理想或估值过高"
        elif funding_score <= 6.0:
            risks["融资风险"] = "中 - 融资情况一般，需关注后续进展"
        else:
            risks["融资风险"] = "低 - 融资情况良好"
        
        return risks
    
    def _assess_data_quality(self, data: Dict) -> float:
        """评估数据质量"""
        if not data:
            return 0.0
        
        quality = 0.5  # 基础质量分
        
        # 关键字段完整性
        required_fields = ["company_name", "funding_amount", "industry"]
        present_fields = sum(1 for field in required_fields if field in data)
        completeness = present_fields / len(required_fields)
        quality += (completeness - 0.5) * 0.3
        
        # 数据详细程度
        detail_score = min(len(str(data)) / 500, 1.0)  # 数据量越大越详细
        quality += detail_score * 0.2
        
        return max(0.0, min(1.0, quality))
    
    def _calculate_overall_confidence(self, funding_info: Dict, additional_data: Optional[Dict]) -> float:
        """计算总体置信度"""
        funding_quality = self._assess_data_quality(funding_info)
        additional_quality = self._assess_data_quality(additional_data) if additional_data else 0
        
        # 融资信息质量权重更高
        overall_confidence = funding_quality * 0.7 + additional_quality * 0.3
        
        # 融资信息提取置信度
        extraction_confidence = funding_info.get('extraction_confidence', 0.5)
        overall_confidence *= extraction_confidence
        
        return round(overall_confidence, 3)
    
    # ========== 辅助方法 ==========
    
    def _parse_funding_amount(self, amount_str: str) -> float:
        """解析融资金额为数值（单位：百万人民币）"""
        if not amount_str:
            return 0.0
        
        try:
            # 提取数字部分
            import re
            match = re.search(r'(\d+(?:\.\d+)?)', amount_str.replace(',', ''))
            if not match:
                return 0.0
            
            number = float(match.group(1))
            
            # 确定数量级
            if '亿' in amount_str:
                number *= 100  # 亿 -> 百万
            elif '千万' in amount_str:
                number *= 10   # 千万 -> 百万
            elif '万' in amount_str:
                number *= 0.01 # 万 -> 百万
            
            # 货币转换（简化的汇率）
            if '美元' in amount_str or 'USD' in amount_str or '$' in amount_str:
                number *= 7.2  # 美元转人民币汇率
            
            return number
            
        except:
            return 0.0
    
    def _parse_funding_round(self, round_str: str) -> int:
        """解析融资轮次为数值"""
        round_mapping = {
            "种子": 1, "天使": 1, "Pre-A": 2, "A": 3, "B": 4, 
            "C": 5, "D": 6, "E": 7, "战略": 8
        }
        
        if not round_str:
            return 0
        
        for key, value in round_mapping.items():
            if key in round_str:
                return value
        
        return 0
    
    def _has_top_investors(self, investors: List[str]) -> bool:
        """检查是否有顶级投资机构"""
        if not investors:
            return False
        
        all_top_investors = []
        for category in self.top_investors.values():
            all_top_investors.extend(category)
        
        for investor in investors:
            for top_investor in all_top_investors:
                if top_investor in investor:
                    return True
        
        return False
    
    def _score_investor_quality(self, investors: List[str]) -> float:
        """评分投资方质量"""
        if not investors:
            return 5.0
        
        score = 5.0  # 基础分
        
        # 顶级投资机构加分
        if self._has_top_investors(investors):
            score += 3.0
        
        # 多个投资方加分
        if len(investors) >= 3:
            score += 1.0
        elif len(investors) >= 2:
            score += 0.5
        
        return min(score, 10.0)
    
    def _score_team_background_simple(self, team_desc: str) -> float:
        """评分团队背景（简化版，用于特征提取）"""
        if not team_desc:
            return 5.0
        
        score = 5.0
        
        # 明星背景关键词加分
        keyword_count = sum(1 for keyword in self.star_team_keywords if keyword in team_desc)
        score += min(keyword_count * 1.0, 3.0)  # 最多加3分
        
        # 描述长度（一定程度上反映信息详细程度）
        desc_length = len(team_desc)
        if desc_length >= 200:
            score += 1.0
        elif desc_length >= 100:
            score += 0.5
        
        return min(score, 10.0)
    
    def _score_tech_sophistication(self, tech_desc: str) -> float:
        """评分技术复杂度"""
        if not tech_desc:
            return 5.0
        
        score = 5.0
        
        # 技术关键词检测
        tech_keywords = ["AI", "人工智能", "机器学习", "深度学习", "大模型", 
                        "量子", "区块链", "自动驾驶", "机器人", "芯片", 
                        "半导体", "生物技术", "基因编辑", "新材料"]
        
        keyword_count = sum(1 for keyword in tech_keywords if keyword in tech_desc)
        score += min(keyword_count * 0.5, 3.0)  # 最多加3分
        
        # 描述详细程度
        desc_length = len(tech_desc)
        if desc_length >= 150:
            score += 1.0
        elif desc_length >= 80:
            score += 0.5
        
        return min(score, 10.0)

class AssessmentPipeline:
    """评估流水线"""
    
    def __init__(self):
        """初始化流水线"""
        self.assessor = CompanyAssessment()
        
    def process_funding_data(self, funding_data: Dict) -> List[Dict]:
        """
        处理融资数据，生成评估报告
        
        参数:
            funding_data: 从公众号抓取的融资数据，格式为 {公众号: [融资信息列表]}
        
        返回: 评估报告列表
        """
        logger.info("开始处理融资数据进行评估")
        
        all_reports = []
        
        for account_name, funding_list in funding_data.items():
            logger.info(f"处理公众号: {account_name}, 融资信息数量: {len(funding_list)}")
            
            for funding_info in funding_list:
                try:
                    # 模拟获取附加数据（在实际部署中这里会进行网络搜索）
                    additional_data = self._simulate_additional_data_search(funding_info)
                    
                    # 进行评估
                    report = self.assessor.assess_company(funding_info, additional_data)
                    all_reports.append(report)
                    
                    logger.debug(f"评估完成: {funding_info.get('company_name')} - {report['decision']['type']}")
                    
                except Exception as e:
                    logger.error(f"评估失败: {funding_info.get('company_name', '未知公司')} - {e}")
                    continue
        
        logger.info(f"评估流水线完成，生成 {len(all_reports)} 份报告")
        return all_reports
    
    def _simulate_additional_data_search(self, funding_info: Dict) -> Dict:
        """模拟网络搜索获取附加数据"""
        company_name = funding_info.get('company_name', '')
        industry = funding_info.get('industry', '未分类')
        
        # 模拟数据（在实际部署中这里会调用网络搜索API）
        simulated_data = {
            "company_name": company_name,
            "industry": industry,
            "employee_count": self._simulate_employee_count(),
            "founded_year": self._simulate_founded_year(),
            "team_description": self._simulate_team_description(company_name, industry),
            "technology_description": self._simulate_tech_description(industry),
            "patent_count": self._simulate_patent_count()
        }
        
        return simulated_data
    
    def _simulate_employee_count(self) -> int:
        """模拟员工数量"""
        import random
        return random.randint(10, 500)
    
    def _simulate_founded_year(self) -> int:
        """模拟成立年份"""
        import random
        return random.randint(2018, 2025)
    
    def _simulate_team_description(self, company_name: str, industry: str) -> str:
        """模拟团队描述"""
        templates = [
            f"{company_name}核心团队由来自知名科技公司的资深专家组成",
            f"创始人具有丰富的{industry}行业经验，团队成员多为相关领域博士",
            f"团队背景多元，结合了技术研发、产品管理和市场运营的复合能力",
            f"核心成员在{industry}领域有超过10年的从业经验"
        ]
        import random
        return random.choice(templates)
    
    def _simulate_tech_description(self, industry: str) -> str:
        """模拟技术描述"""
        descriptions = {
            "人工智能": "专注于大语言模型和计算机视觉技术，拥有多项核心专利",
            "量子计算": "研发量子处理器和量子算法，处于国际领先水平",
            "新能源": "开发高效能电池和储能系统，技术达到行业先进水平",
            "生物医药": "基于AI的药物发现平台，加速新药研发流程",
            "半导体": "专注于芯片设计和制造工艺，拥有自主知识产权"
        }
        return descriptions.get(industry, "拥有行业领先的核心技术")
    
    def _simulate_patent_count(self) -> int:
        """模拟专利数量"""
        import random
        return random.randint(0, 20)
    
    def generate_summary_report(self, assessment_reports: List[Dict]) -> Dict:
        """生成汇总报告"""
        logger.info("生成评估汇总报告")
        
        if not assessment_reports:
            return {"error": "无评估报告"}
        
        # 统计决策分布
        decision_counts = {}
        for report in assessment_reports:
            decision_type = report["decision"]["type"]
            decision_counts[decision_type] = decision_counts.get(decision_type, 0) + 1
        
        # 计算平均分数
        total_score = 0
        high_quality_count = 0
        
        for report in assessment_reports:
            total_score += report["scores"]["final_score"]
            if report["scores"]["final_score"] >= 70:
                high_quality_count += 1
        
        avg_score = total_score / len(assessment_reports) if assessment_reports else 0
        high_quality_ratio = high_quality_count / len(assessment_reports) if assessment_reports else 0
        
        # 提取最佳候选
        top_candidates = sorted(
            assessment_reports, 
            key=lambda x: x["scores"]["final_score"], 
            reverse=True
        )[:5]
        
        # 行业分布
        industry_distribution = {}
        for report in assessment_reports:
            industry = report.get("industry", "未分类")
            industry_distribution[industry] = industry_distribution.get(industry, 0) + 1
        
        # 构建汇总报告
        summary = {
            "generation_date": datetime.now().isoformat(),
            "total_companies_assessed": len(assessment_reports),
            "decision_distribution": decision_counts,
            "score_statistics": {
                "average_score": round(avg_score, 2),
                "high_quality_ratio": round(high_quality_ratio, 3),
                "score_range": {
                    "min": min([r["scores"]["final_score"] for r in assessment_reports]) if assessment_reports else 0,
                    "max": max([r["scores"]["final_score"] for r in assessment_reports]) if assessment_reports else 0
                }
            },
            "industry_distribution": industry_distribution,
            "top_candidates": [
                {
                    "company": r["company_name"],
                    "score": round(r["scores"]["final_score"], 2),
                    "decision": r["decision"]["type"],
                    "industry": r.get("industry", "未分类"),
                    "funding_amount": r["funding_info"]["amount"]
                }
                for r in top_candidates
            ],
            "data_quality_summary": {
                "average_confidence": round(sum(r["data_quality"]["overall_confidence"] for r in assessment_reports) / len(assessment_reports), 3) if assessment_reports else 0,
                "high_confidence_count": sum(1 for r in assessment_reports if r["data_quality"]["overall_confidence"] >= 0.8)
            },
            "recommendations": self._generate_recommendations(decision_counts, avg_score)
        }
        
        # 保存报告
        report_file = f"/home/workspace/data/assessment_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        logger.info(f"汇总报告保存到: {report_file}")
        return summary
    
    def _generate_recommendations(self, decision_counts: Dict, avg_score: float) -> List[str]:
        """生成投资建议"""
        recommendations = []
        
        strong_follow_count = decision_counts.get("强烈关注", 0)
        follow_count = decision_counts.get("建议关注", 0)
        
        # 基于优质项目数量
        total_high_quality = strong_follow_count + follow_count
        
        if total_high_quality >= 5:
            recommendations.append("本日发现多个优质投资机会，建议优先跟进")
        elif total_high_quality >= 2:
            recommendations.append("发现部分有潜力的项目，建议选择性关注")
        else:
            recommendations.append("优质项目较少，建议保持观察或调整筛选标准")
        
        # 基于平均分数
        if avg_score >= 75:
            recommendations.append("整体质量较高，市场机会良好")
        elif avg_score >= 65:
            recommendations.append("整体质量中等，需要进一步筛选")
        else:
            recommendations.append("整体质量一般，建议关注其他赛道")
        
        # 基于决策分布
        if decision_counts.get("暂不关注", 0) > len(decision_counts) * 0.5:
            recommendations.append("多数项目评估结果不理想，建议重新评估关注领域")
        
        return recommendations

def test_assessment_model():
    """测试评估模型"""
    print("=== AI评估模型测试 ===")
    
    # 创建评估器
    assessor = CompanyAssessment()
    
    # 测试数据
    test_funding_info = {
        "company_name": "深度智能科技",
        "funding_amount": "1.2亿元",
        "funding_round": "B轮",
        "investors": ["红杉中国", "高瓴资本", "源码资本"],
        "industry": "人工智能",
        "source_account": "36氪Pro",
        "publish_date": "2026-05-31",
        "extraction_confidence": 0.95,
        "article_url": "https://example.com/article"
    }
    
    test_additional_data = {
        "employee_count": 150,
        "founded_year": 2022,
        "team_description": "核心团队来自前Google AI部门，拥有多名AI领域博士",
        "technology_description": "专注于大语言模型和计算机视觉技术，拥有20项核心专利",
        "patent_count": 20
    }
    
    print("1. 测试单个公司评估...")
    try:
        report = assessor.assess_company(test_funding_info, test_additional_data)
        
        print(f"✓ 评估完成")
        print(f"公司: {report['company_name']}")
        print(f"行业: {report['industry']}")
        print(f"综合评分: {report['scores']['final_score']:.2f}")
        print(f"决策: {report['decision']['type']}")
        print(f"置信度: {report['decision']['confidence']:.3f}")
        
        print("\n维度评分:")
        for dimension, score in report['scores']['dimension_scores'].items():
            print(f"  {dimension}: {score:.2f}")
        
        print("\n关键发现:")
        for finding in report['key_findings']:
            print(f"  - {finding}")
        
        print("\n风险评估:")
        for risk, description in report['risk_analysis'].items():
            print(f"  {risk}: {description}")
        
        print("\n下一步建议:")
        for step in report['decision']['next_steps']:
            print(f"  - {step}")
        
        print("\n数据质量:")
        for metric, value in report['data_quality'].items():
            print(f"  {metric}: {value}")
        
        return True
        
    except Exception as e:
        print(f"✗ 评估失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_pipeline():
    """测试评估流水线"""
    print("\n=== 评估流水线测试 ===")
    
    # 创建流水线
    pipeline = AssessmentPipeline()
    
    # 测试数据
    test_funding_data = {
        "36氪Pro": [
            {
                "company_name": "深度智能科技",
                "funding_amount": "1.2亿元",
                "funding_round": "B轮",
                "investors": ["红杉中国", "高瓴资本"],
                "industry": "人工智能",
                "extraction_confidence": 0.95
            },
            {
                "company_name": "量子计算公司",
                "funding_amount": "5000万元",
                "funding_round": "A轮",
                "investors": ["启明创投"],
                "industry": "量子计算",
                "extraction_confidence": 0.85
            }
        ],
        "Strictly VC": [
            {
                "company_name": "NeuroTech AI",
                "funding_amount": "$50M",
                "funding_round": "Series B",
                "investors": ["Sequoia", "Andreessen Horowitz"],
                "industry": "人工智能",
                "extraction_confidence": 0.90
            }
        ]
    }
    
    print("1. 处理融资数据...")
    try:
        assessment_reports = pipeline.process_funding_data(test_funding_data)
        
        print(f"✓ 处理完成，生成 {len(assessment_reports)} 份评估报告")
        
        print("\n2. 生成汇总报告...")
        summary = pipeline.generate_summary_report(assessment_reports)
        
        print(f"✓ 汇总报告生成成功")
        print(f"评估公司总数: {summary['total_companies_assessed']}")
        print(f"平均分数: {summary['score_statistics']['average_score']:.2f}")
        
        print("\n决策分布:")
        for decision, count in summary['decision_distribution'].items():
            print(f"  {decision}: {count}")
        
        print("\n行业分布:")
        for industry, count in summary['industry_distribution'].items():
            print(f"  {industry}: {count}")
        
        print("\n最佳候选:")
        for i, candidate in enumerate(summary['top_candidates'], 1):
            print(f"  {i}. {candidate['company']} - {candidate['score']}分 ({candidate['decision']})")
        
        print("\n投资建议:")
        for recommendation in summary['recommendations']:
            print(f"  - {recommendation}")
        
        return True
        
    except Exception as e:
        print(f"✗ 流水线测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """主测试函数"""
    print("=" * 60)
    print("AI评估模型与follow/not决策系统 - 功能测试")
    print("=" * 60)
    
    tests = [
        ("评估模型功能", test_assessment_model),
        ("评估流水线", test_pipeline)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            print(f"\n{'='*40}")
            print(f"测试: {test_name}")
            print('='*40)
            
            success = test_func()
            results.append((test_name, success))
            
        except Exception as e:
            print(f"测试 '{test_name}' 执行异常: {e}")
            results.append((test_name, False))
    
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    
    passed = 0
    for test_name, success in results:
        status = "✓ 通过" if success else "✗ 失败"
        print(f"{test_name:20} {status}")
        if success:
            passed += 1
    
    print(f"\n通过测试: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("\n✅ 所有测试通过!")
        print("\n下一步:")
        print("-" * 40)
        print("1. 集成到公众号监控系统:")
        print("   - 调用 AssessmentPipeline.process_funding_data()")
        print("   - 将评估结果同步到飞书表格")
        print("\n2. 配置自动化工作流:")
        print("   - 每日定时执行公众号抓取 → 数据解析 → AI评估")
        print("   - 生成每日投资简报")
        print("\n3. 优化评估模型:")
        print("   - 增加更多数据源")
        print("   - 优化评分算法")
        print("   - 基于历史数据持续学习")
    else:
        print(f"\n❌ {len(tests) - passed} 个测试失败")
    
    return all(success for _, success in results)

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)