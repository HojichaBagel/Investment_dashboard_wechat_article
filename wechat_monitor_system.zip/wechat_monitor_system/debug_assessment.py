#!/usr/bin/env python3
"""
调试AI评估模型
"""

import sys
sys.path.append('/home/workspace')

from ai_assessment_model import CompanyAssessment, AssessmentFactor, DecisionType

# 创建评估器
assessor = CompanyAssessment()

# 测试数据
test_funding_info = {
    "company_name": "深度智能科技",
    "funding_amount": "1.2亿元",
    "funding_round": "B轮",
    "investors": ["红杉中国", "高瓴资本", "源码资本"],
    "industry": "人工智能",
    "source_account": "36氪Pro",
    "publish_date": "2026-05-31",
    "extraction_confidence": 0.95,
    "article_url": "https://example.com/article"
}

test_additional_data = {
    "employee_count": 150,
    "founded_year": 2022,
    "team_description": "核心团队来自前Google AI部门，拥有多名AI领域博士",
    "technology_description": "专注于大语言模型和计算机视觉技术，拥有20项核心专利",
    "patent_count": 20
}

print("1. 测试特征提取...")
try:
    features = assessor._extract_features(test_funding_info, test_additional_data)
    print(f"✓ 特征提取成功")
    print(f"特征数量: {len(features)}")
    print("关键特征:")
    for key, value in list(features.items())[:10]:
        print(f"  {key}: {value}")
except Exception as e:
    print(f"✗ 特征提取失败: {e}")
    import traceback
    traceback.print_exc()

print("\n2. 测试单个维度评分...")
try:
    all_data = {
        "funding_info": test_funding_info,
        "additional_data": test_additional_data,
        "extracted_features": features
    }
    
    # 测试市场机会维度
    score, sub_scores = assessor._score_market_opportunity(features)
    print(f"✓ 市场机会维度评分成功")
    print(f"  维度分数: {score}")
    print(f"  子维度分数: {sub_scores}")
except Exception as e:
    print(f"✗ 维度评分失败: {e}")
    import traceback
    traceback.print_exc()

print("\n3. 测试维度路由...")
try:
    # 测试所有维度
    for factor in AssessmentFactor:
        print(f"\n  测试维度: {factor.value}")
        score, sub_scores = assessor._score_dimension(factor, all_data)
        print(f"    分数: {score}")
        print(f"    子维度: {list(sub_scores.keys())}")
    
    print(f"\n✓ 所有维度路由成功")
except Exception as e:
    print(f"✗ 维度路由失败: {e}")
    import traceback
    traceback.print_exc()

print("\n4. 测试综合评估...")
try:
    report = assessor.assess_company(test_funding_info, test_additional_data)
    print(f"✓ 综合评估成功")
    print(f"公司: {report['company_name']}")
    print(f"综合评分: {report['scores']['final_score']:.2f}")
    print(f"决策: {report['decision']['type']}")
except Exception as e:
    print(f"✗ 综合评估失败: {e}")
    import traceback
    traceback.print_exc()