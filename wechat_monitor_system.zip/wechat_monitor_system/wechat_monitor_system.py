#!/usr/bin/env python3
"""
公众号自动阅读与融资监控系统 - 完整集成版

功能：
1. 公众号内容自动抓取和解析
2. AI评估与follow/not决策
3. 结果同步到飞书多维表格
4. 生成每日投资简报
5. 定时任务和自动化管理

使用方式：
1. 每日运行：python wechat_monitor_system.py --daily
2. 手动运行：python wechat_monitor_system.py --manual
3. 测试模式：python wechat_monitor_system.py --test
4. 配置定时任务：python wechat_monitor_system.py --setup-cron

系统架构：
┌─────────────────────────────────────────────────────────┐
│                   公众号监控系统                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│  │ 内容抓取  │→│ AI评估   │→│ 飞书同步 │               │
│  └──────────┘  └──────────┘  └──────────┘              │
└─────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────┐
│                   飞书多维表格                            │
│  ┌────────────────────────────────────────────┐        │
│  │ 候选公司库（实时更新）                       │        │
│  │ • 公司信息 • 融资数据 • AI评分 • 决策建议    │        │
│  └────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────┘
"""

import json
import os
import sys
import logging
from datetime import datetime, timedelta
import argparse

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from wechat_crawler import WeChatCrawler
from ai_assessment_model import AssessmentPipeline
from automated_workflow import AutomatedWorkflow
from feishu_integration import IntegratedWorkflow, FeishuBaseIntegration

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/workspace/logs/system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WeChatMonitorSystem:
    """公众号监控系统 - 主控制器"""
    
    def __init__(self, config_path: str = "/home/workspace/wechat_config.json"):
        """初始化系统"""
        self.config_path = config_path
        
        # 加载配置
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # 初始化组件
        self.crawler = WeChatCrawler(config_path)
        self.assessment_pipeline = AssessmentPipeline()
        self.automated_workflow = AutomatedWorkflow(config_path)
        self.integrated_workflow = IntegratedWorkflow()
        self.feishu_integration = FeishuBaseIntegration()
        
        # 系统状态
        self.system_status = {
            "initialized": datetime.now().isoformat(),
            "version": "1.0.0",
            "components": {
                "wechat_crawler": True,
                "assessment_pipeline": True,
                "automated_workflow": True,
                "feishu_integration": True
            },
            "last_run": None,
            "total_runs": 0,
            "successful_runs": 0
        }
        
        # 创建必要的目录
        self._create_directories()
        
        logger.info("公众号监控系统初始化完成")
        logger.info(f"系统版本: {self.system_status['version']}")
        logger.info(f"配置路径: {config_path}")
    
    def _create_directories(self):
        """创建必要的目录"""
        directories = [
            "/home/workspace/logs",
            "/home/workspace/data",
            "/home/workspace/output",
            "/home/workspace/output/daily_reports",
            "/home/workspace/output/assessment_results",
            "/home/workspace/output/import_files",
            "/home/workspace/output/system_reports"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def run_daily_pipeline(self, days_back: int = 1, sync_to_base: bool = True) -> Dict:
        """
        运行每日完整流水线
        
        步骤：
        1. 公众号内容抓取
        2. 融资信息提取
        3. AI评估与决策
        4. 结果汇总
        5. 飞书表格同步
        6. 生成报告
        
        返回: 流水线执行结果
        """
        logger.info("=" * 80)
        logger.info("公众号监控系统 - 每日流水线开始执行")
        logger.info(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"抓取天数: {days_back} 天")
        logger.info(f"飞书同步: {'启用' if sync_to_base else '禁用'}")
        logger.info("=" * 80)
        
        pipeline_result = {
            "pipeline_name": "daily_pipeline",
            "start_time": datetime.now().isoformat(),
            "days_back": days_back,
            "sync_to_base": sync_to_base,
            "steps": []
        }
        
        try:
            # 步骤1: 公众号内容抓取
            logger.info("\n📱 步骤1: 公众号内容抓取")
            step1_result = self._step_crawl_content(days_back)
            pipeline_result["steps"].append({
                "name": "公众号抓取",
                "status": "completed",
                "duration": step1_result.get("duration", 0),
                "result": step1_result
            })
            
            funding_data = step1_result.get("funding_data", {})
            if not funding_data or sum(len(v) for v in funding_data.values()) == 0:
                logger.warning("⚠️ 未提取到融资信息，流水线提前结束")
                pipeline_result["early_exit"] = True
                pipeline_result["reason"] = "无融资数据"
                return self._finalize_pipeline(pipeline_result, success=True)
            
            # 步骤2: AI评估与决策
            logger.info("\n🤖 步骤2: AI评估与follow/not决策")
            step2_result = self._step_assessment(funding_data)
            pipeline_result["steps"].append({
                "name": "AI评估",
                "status": "completed",
                "duration": step2_result.get("duration", 0),
                "result": step2_result
            })
            
            assessment_reports = step2_result.get("assessment_reports", [])
            if not assessment_reports:
                logger.warning("⚠️ 未生成评估报告，流水线提前结束")
                pipeline_result["early_exit"] = True
                pipeline_result["reason"] = "无评估报告"
                return self._finalize_pipeline(pipeline_result, success=True)
            
            # 步骤3: 生成汇总报告
            logger.info("\n📊 步骤3: 生成汇总报告")
            step3_result = self._step_generate_summary(assessment_reports)
            pipeline_result["steps"].append({
                "name": "报告生成",
                "status": "completed",
                "duration": step3_result.get("duration", 0),
                "result": step3_result
            })
            
            # 步骤4: 飞书表格集成
            if sync_to_base:
                logger.info("\n🔄 步骤4: 飞书表格集成")
                step4_result = self._step_feishu_integration(assessment_reports)
                pipeline_result["steps"].append({
                    "name": "飞书集成",
                    "status": "completed",
                    "duration": step4_result.get("duration", 0),
                    "result": step4_result
                })
            else:
                logger.info("\n⏭️  步骤4: 跳过飞书表格集成")
                pipeline_result["steps"].append({
                    "name": "飞书集成",
                    "status": "skipped",
                    "reason": "同步功能已禁用"
                })
            
            # 步骤5: 生成系统报告
            logger.info("\n📋 步骤5: 生成系统报告")
            step5_result = self._step_system_report(pipeline_result)
            pipeline_result["steps"].append({
                "name": "系统报告",
                "status": "completed",
                "duration": step5_result.get("duration", 0),
                "result": step5_result
            })
            
            # 更新系统状态
            self.system_status["last_run"] = datetime.now().isoformat()
            self.system_status["total_runs"] += 1
            self.system_status["successful_runs"] += 1
            
            # 最终化流水线
            final_result = self._finalize_pipeline(pipeline_result, success=True)
            
            logger.info("\n" + "=" * 80)
            logger.info("🎉 每日流水线执行成功!")
            logger.info(f"⏱️  总执行时长: {final_result.get('total_duration', 0):.1f}秒")
            logger.info(f"📊 处理融资信息: {step1_result.get('total_funding', 0)}条")
            logger.info(f"🤖 生成评估报告: {len(assessment_reports)}份")
            if sync_to_base:
                logger.info(f"🔄 飞书同步记录: {step4_result.get('sync_result', {}).get('successful', 0)}条")
            logger.info("=" * 80)
            
            return final_result
            
        except KeyboardInterrupt:
            logger.warning("⏹️  流水线被用户中断")
            pipeline_result["interrupted"] = True
            return self._finalize_pipeline(pipeline_result, success=False, reason="用户中断")
            
        except Exception as e:
            logger.error(f"❌ 流水线执行失败: {e}")
            import traceback
            traceback.print_exc()
            
            pipeline_result["error"] = str(e)
            return self._finalize_pipeline(pipeline_result, success=False, reason=str(e))
    
    def _step_crawl_content(self, days_back: int) -> Dict:
        """步骤1: 公众号内容抓取"""
        start_time = datetime.now()
        
        try:
            funding_data = self.crawler.crawl_and_parse(days_back)
            total_funding = sum(len(v) for v in funding_data.values())
            
            # 生成抓取报告
            crawl_report = {
                "total_accounts": len(funding_data),
                "total_funding": total_funding,
                "account_details": [
                    {
                        "account": account,
                        "funding_count": len(fundings),
                        "sample_fundings": [
                            {
                                "company": f.get("company_name"),
                                "amount": f.get("funding_amount"),
                                "confidence": f.get("extraction_confidence")
                            }
                            for f in fundings[:3]  # 每个公众号取前3条
                        ]
                    }
                    for account, fundings in funding_data.items()
                    if fundings
                ],
                "crawl_time": datetime.now().isoformat()
            }
            
            # 保存原始数据
            today = datetime.now().strftime("%Y%m%d")
            raw_data_file = f"/home/workspace/output/raw_funding_data_{today}.json"
            with open(raw_data_file, 'w', encoding='utf-8') as f:
                json.dump(funding_data, f, ensure_ascii=False, indent=2)
            
            duration = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ 抓取完成: {total_funding} 条融资信息来自 {len(funding_data)} 个公众号")
            logger.info(f"   原始数据: {raw_data_file}")
            
            return {
                "success": True,
                "funding_data": funding_data,
                "total_funding": total_funding,
                "raw_data_file": raw_data_file,
                "crawl_report": crawl_report,
                "duration": duration
            }
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ 抓取失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "duration": duration
            }
    
    def _step_assessment(self, funding_data: Dict) -> Dict:
        """步骤2: AI评估与决策"""
        start_time = datetime.now()
        
        try:
            assessment_reports = self.assessment_pipeline.process_funding_data(funding_data)
            
            # 统计决策分布
            decision_counts = {}
            score_ranges = {"优秀(≥80)": 0, "良好(70-79)": 0, "一般(60-69)": 0, "较差(<60)": 0}
            
            for report in assessment_reports:
                decision = report["decision"]["type"]
                decision_counts[decision] = decision_counts.get(decision, 0) + 1
                
                # 分数分布
                final_score = report["scores"]["final_score"]
                if final_score >= 80:
                    score_ranges["优秀(≥80)"] += 1
                elif final_score >= 70:
                    score_ranges["良好(70-79)"] += 1
                elif final_score >= 60:
                    score_ranges["一般(60-69)"] += 1
                else:
                    score_ranges["较差(<60)"] += 1
            
            # 生成评估报告
            assessment_report = {
                "total_assessments": len(assessment_reports),
                "decision_distribution": decision_counts,
                "score_distribution": score_ranges,
                "top_candidates": [
                    {
                        "company": r["company_name"],
                        "score": round(r["scores"]["final_score"], 1),
                        "decision": r["decision"]["type"],
                        "industry": r.get("industry", "未分类"),
                        "funding_amount": r["funding_info"]["amount"]
                    }
                    for r in sorted(assessment_reports, 
                                  key=lambda x: x["scores"]["final_score"], 
                                  reverse=True)[:5]
                ],
                "assessment_time": datetime.now().isoformat()
            }
            
            # 保存评估结果
            today = datetime.now().strftime("%Y%m%d")
            assessment_file = f"/home/workspace/output/assessment_results/assessments_{today}.json"
            with open(assessment_file, 'w', encoding='utf-8') as f:
                json.dump(assessment_reports, f, ensure_ascii=False, indent=2)
            
            duration = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ 评估完成: {len(assessment_reports)} 份评估报告")
            logger.info(f"   决策分布: {dict(decision_counts)}")
            logger.info(f"   评估结果: {assessment_file}")
            
            return {
                "success": True,
                "assessment_reports": assessment_reports,
                "assessment_file": assessment_file,
                "assessment_report": assessment_report,
                "duration": duration
            }
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ 评估失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "duration": duration
            }
    
    def _step_generate_summary(self, assessment_reports: List[Dict]) -> Dict:
        """步骤3: 生成汇总报告"""
        start_time = datetime.now()
        
        try:
            # 生成详细汇总报告
            summary_report = self.assessment_pipeline.generate_summary_report(assessment_reports)
            
            # 保存汇总报告
            today = datetime.now().strftime("%Y%m%d")
            summary_file = f"/home/workspace/output/daily_reports/daily_summary_{today}.json"
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary_report, f, ensure_ascii=False, indent=2)
            
            # 生成可读的文本报告
            text_report = self._generate_daily_text_report(summary_report)
            text_file = f"/home/workspace/output/daily_reports/daily_summary_{today}.txt"
            with open(text_file, 'w', encoding='utf-8') as f:
                f.write(text_report)
            
            duration = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ 报告生成完成")
            logger.info(f"   汇总报告: {summary_file}")
            logger.info(f"   文本报告: {text_file}")
            
            # 打印简要报告
            print("\n" + "=" * 60)
            print("📋 今日投资简报")
            print("=" * 60)
            print(f"评估公司总数: {summary_report.get('total_companies_assessed', 0)} 家")
            print(f"平均综合评分: {summary_report.get('score_statistics', {}).get('average_score', 0):.1f} 分")
            print("\n决策分布:")
            for decision, count in summary_report.get('decision_distribution', {}).items():
                print(f"  • {decision}: {count} 家")
            print("\n最佳候选:")
            for i, candidate in enumerate(summary_report.get('top_candidates', [])[:3], 1):
                print(f"  {i}. {candidate['company']} - {candidate['score']}分 ({candidate['decision']})")
            print("=" * 60)
            
            return {
                "success": True,
                "summary_file": summary_file,
                "text_file": text_file,
                "summary_report": summary_report,
                "duration": duration
            }
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ 报告生成失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "duration": duration
            }
    
    def _generate_daily_text_report(self, summary_report: Dict) -> str:
        """生成每日文本报告"""
        report_date = summary_report.get("generation_date", datetime.now().isoformat())
        
        report = f"""
{'='*60}
📱 公众号自动阅读与融资监控系统 - 每日简报
📅 报告日期: {report_date[:10]}
⏰ 生成时间: {datetime.now().strftime('%H:%M:%S')}
{'='*60}

📊 执行摘要
总评估公司数: {summary_report.get('total_companies_assessed', 0)} 家
平均综合评分: {summary_report.get('score_statistics', {}).get('average_score', 0):.1f} 分
高分比例(≥70分): {summary_report.get('score_statistics', {}).get('high_quality_ratio', 0)*100:.1f}%

📈 决策分布
"""
        
        # 决策分布
        decision_dist = summary_report.get("decision_distribution", {})
        total = summary_report.get('total_companies_assessed', 1)
        for decision, count in decision_dist.items():
            percentage = (count / total * 100) if total > 0 else 0
            report += f"• {decision}: {count} 家 ({percentage:.1f}%)\n"
        
        report += f"""
🏢 行业分布
"""
        
        # 行业分布
        industry_dist = summary_report.get("industry_distribution", {})
        for industry, count in industry_dist.items():
            report += f"• {industry}: {count} 家\n"
        
        report += f"""
🏆 今日最佳候选
"""
        
        # 最佳候选
        top_candidates = summary_report.get("top_candidates", [])[:5]
        for i, candidate in enumerate(top_candidates, 1):
            report += f"{i}. {candidate['company']}\n"
            report += f"   评分: {candidate['score']}分 | 行业: {candidate['industry']}\n"
            report += f"   融资金额: {candidate['funding_amount']} | 决策: {candidate['decision']}\n"
        
        report += f"""
💡 投资建议
"""
        
        # 投资建议
        recommendations = summary_report.get("recommendations", [])
        for rec in recommendations:
            report += f"• {rec}\n"
        
        report += f"""
📋 数据质量
平均置信度: {summary_report.get('data_quality_summary', {}).get('average_confidence', 0):.3f}
高置信度评估(≥0.8): {summary_report.get('data_quality_summary', {}).get('high_confidence_count', 0)} 个

🔧 系统建议
"""
        
        # 系统建议
        if summary_report.get('total_companies_assessed', 0) >= 5:
            report += "1. 发现多个投资机会，建议优先跟进高分候选\n"
        else:
            report += "1. 今日机会有限，建议关注其他信息源\n"
        
        if summary_report.get('score_statistics', {}).get('average_score', 0) >= 70:
            report += "2. 整体质量较高，市场机会良好\n"
        else:
            report += "2. 整体质量一般，建议调整筛选标准\n"
        
        report += "3. 定期回顾评估结果，优化投资策略\n"
        
        report += f"""
{'='*60}
📞 后续行动
• 查看详细报告: /home/workspace/output/daily_reports/
• 飞书表格同步: https://sensetime.feishu.cn/base/XCpvbzWuyayJ8wsmTv7cpAB3npf
• 系统日志: /home/workspace/logs/system.log
{'='*60}
"""
        
        return report
    
    def _step_feishu_integration(self, assessment_reports: List[Dict]) -> Dict:
        """步骤4: 飞书表格集成"""
        start_time = datetime.now()
        
        try:
            # 运行集成工作流
            integration_result = self.integrated_workflow.run_integrated_workflow(
                assessment_reports, 
                sync_to_base=True
            )
            
            duration = (datetime.now() - start_time).total_seconds()
            
            if integration_result.get("success"):
                logger.info(f"✅ 飞书集成完成")
                
                # 提取同步结果
                sync_result = None
                for step in integration_result.get("steps", []):
                    if step.get("name") == "表格同步":
                        sync_result = step.get("result", {})
                        break
                
                if sync_result:
                    logger.info(f"   同步记录: {sync_result.get('successful', 0)} 成功, {sync_result.get('failed', 0)} 失败")
                    logger.info(f"   成功率: {sync_result.get('success_rate', 0):.1f}%")
                
                return {
                    "success": True,
                    "integration_result": integration_result,
                    "sync_result": sync_result,
                    "duration": duration
                }
            else:
                logger.error(f"❌ 飞书集成失败: {integration_result.get('error', '未知错误')}")
                return {
                    "success": False,
                    "error": integration_result.get("error"),
                    "integration_result": integration_result,
                    "duration": duration
                }
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ 飞书集成异常: {e}")
            return {
                "success": False,
                "error": str(e),
                "duration": duration
            }
    
    def _step_system_report(self, pipeline_result: Dict) -> Dict:
        """步骤5: 生成系统报告"""
        start_time = datetime.now()
        
        try:
            # 生成系统状态报告
            system_report = {
                "system_info": self.system_status,
                "pipeline_summary": {
                    "total_steps": len(pipeline_result.get("steps", [])),
                    "completed_steps": len([s for s in pipeline_result.get("steps", []) 
                                          if s.get("status") == "completed"]),
                    "failed_steps": len([s for s in pipeline_result.get("steps", []) 
                                       if s.get("status") == "failed"]),
                    "total_duration": sum(s.get("duration", 0) for s in pipeline_result.get("steps", []))
                },
                "generated_files": self._collect_generated_files(),
                "generation_time": datetime.now().isoformat()
            }
            
            # 保存系统报告
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            system_report_file = f"/home/workspace/output/system_reports/system_report_{timestamp}.json"
            with open(system_report_file, 'w', encoding='utf-8') as f:
                json.dump(system_report, f, ensure_ascii=False, indent=2)
            
            duration = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ 系统报告生成完成: {system_report_file}")
            
            return {
                "success": True,
                "system_report_file": system_report_file,
                "system_report": system_report,
                "duration": duration
            }
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ 系统报告生成失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "duration": duration
            }
    
    def _collect_generated_files(self) -> List[Dict]:
        """收集生成的文件"""
        generated_files = []
        output_dir = "/home/workspace/output"
        
        for root, dirs, files in os.walk(output_dir):
            for file in files:
                if file.endswith(('.json', '.txt', '.log')):
                    filepath = os.path.join(root, file)
                    rel_path = os.path.relpath(filepath, output_dir)
                    
                    # 获取文件信息
                    try:
                        stat = os.stat(filepath)
                        generated_files.append({
                            "path": rel_path,
                            "full_path": filepath,
                            "size": stat.st_size,
                            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                            "type": "log" if file.endswith('.log') else "data"
                        })
                    except:
                        pass
        
        return generated_files
    
    def _finalize_pipeline(self, pipeline_result: Dict, success: bool, reason: str = None) -> Dict:
        """最终化流水线结果"""
        pipeline_result["end_time"] = datetime.now().isoformat()
        pipeline_result["success"] = success
        
        if reason:
            pipeline_result["reason"] = reason
        
        # 计算总时长
        start_time = datetime.fromisoformat(pipeline_result["start_time"].replace('Z', '+00:00'))
        end_time = datetime.fromisoformat(pipeline_result["end_time"].replace('Z', '+00:00'))
        pipeline_result["total_duration"] = (end_time - start_time).total_seconds()
        
        # 保存流水线结果
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        pipeline_file = f"/home/workspace/output/system_reports/pipeline_result_{timestamp}.json"
        with open(pipeline_file, 'w', encoding='utf-8') as f:
            json.dump(pipeline_result, f, ensure_ascii=False, indent=2)
        
        logger.info(f"流水线结果保存到: {pipeline_file}")
        
        return pipeline_result
    
    def run_test_mode(self):
        """运行测试模式"""
        logger.info("运行测试模式...")
        
        # 创建测试配置
        test_config = {
            "wechat_accounts": [
                {
                    "name": "测试公众号",
                    "description": "测试用公众号",
                    "priority": 1,
                    "keywords": ["测试"],
                    "language": "zh",
                    "expected_daily_articles": 1,
                    "reliability_score": 0.9
                }
            ],
            "parsing_rules": {
                "company_name_patterns": ["([\\u4e00-\\u9fa5a-zA-Z0-9&]+)(?:公司|科技|技术|智能|数据)"],
                "funding_amount_patterns": ["(\\d+(?:\\.\\d+)?)\\s*(?:万|千万|亿|百万|十亿)?\\s*(?:元|人民币|RMB)"],
                "round_patterns": ["(?:种子|天使|Pre-A|A|B|C|D|E|战略)(?:轮|阶段)"],
                "investor_patterns": ["(?:领投|跟投|投资方)[：:]\\s*([^，。\\n]+)"]
            },
            "monitoring_schedule": {
                "daily_crawl_times": ["06:00"],
                "analysis_window_hours": 1,
                "retry_attempts": 1,
                "retry_delay_seconds": 300
            },
            "output_settings": {
                "max_companies_per_day": 5,
                "min_confidence_score": 0.7,
                "save_raw_html": True,
                "backup_days": 7
            }
        }
        
        test_config_file = "/home/workspace/test_config_system.json"
        with open(test_config_file, 'w', encoding='utf-8') as f:
            json.dump(test_config, f, ensure_ascii=False, indent=2)
        
        # 使用测试配置运行系统
        test_system = WeChatMonitorSystem(test_config_file)
        result = test_system.run_daily_pipeline(days_back=0, sync_to_base=False)
        
        # 清理测试配置
        if os.path.exists(test_config_file):
            os.remove(test_config_file)
        
        return result
    
    def cleanup_old_files(self, days_to_keep: int = 7):
        """清理旧文件"""
        logger.info(f"清理 {days_to_keep} 天前的旧文件...")
        
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        deleted_count = 0
        
        # 清理输出目录
        output_dirs = [
            "/home/workspace/output/daily_reports",
            "/home/workspace/output/assessment_results",
            "/home/workspace/output/import_files",
            "/home/workspace/output/system_reports"
        ]
        
        for output_dir in output_dirs:
            if os.path.exists(output_dir):
                for filename in os.listdir(output_dir):
                    filepath = os.path.join(output_dir, filename)
                    if os.path.isfile(filepath):
                        try:
                            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
                            if mtime < cutoff_date:
                                os.remove(filepath)
                                deleted_count += 1
                                logger.debug(f"删除旧文件: {filepath}")
                        except:
                            pass
        
        logger.info(f"清理完成，删除了 {deleted_count} 个旧文件")
        return deleted_count
    
    def get_system_status(self) -> Dict:
        """获取系统状态"""
        status = self.system_status.copy()
        
        # 添加文件系统信息
        status["file_system"] = {
            "output_dir": "/home/workspace/output",
            "log_dir": "/home/workspace/logs",
            "data_dir": "/home/workspace/data",
            "total_files": self._count_files("/home/workspace/output"),
            "last_cleanup": None  # 可以添加清理记录
        }
        
        # 添加配置信息
        status["config"] = {
            "path": self.config_path,
            "total_accounts": len(self.config.get("wechat_accounts", [])),
            "monitoring_schedule": self.config.get("monitoring_schedule", {})
        }
        
        return status

    def _count_files(self, directory: str) -> int:
        """统计目录中的文件数量"""
        count = 0
        if os.path.exists(directory):
            for root, dirs, files in os.walk(directory):
                count += len(files)
        return count

def setup_cron_job():
    """设置cron定时任务"""
    cron_config = f"""
# 公众号自动阅读与融资监控系统 - 定时任务配置
# 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# 每日早上8点执行（避开公众号推送高峰）
0 8 * * * cd /home/workspace && /usr/bin/python3 wechat_monitor_system.py --daily >> /home/workspace/logs/cron_daily.log 2>&1

# 每周一早上9点执行完整同步（包含飞书表格同步）
0 9 * * 1 cd /home/workspace && /usr/bin/python3 wechat_monitor_system.py --daily --sync >> /home/workspace/logs/cron_weekly.log 2>&1

# 每月1号早上10点清理旧文件（保留30天）
0 10 1 * * cd /home/workspace && /usr/bin/python3 wechat_monitor_system.py --cleanup 30 >> /home/workspace/logs/cron_cleanup.log 2>&1

# 测试模式（每小时执行一次，用于调试）
# 0 * * * * cd /home/workspace && /usr/bin/python3 wechat_monitor_system.py --test >> /home/workspace/logs/cron_test.log 2>&1
"""
    
    cron_file = "/home/workspace/cron_job_setup.txt"
    with open(cron_file, 'w', encoding='utf-8') as f:
        f.write(cron_config)
    
    print(f"Cron配置已保存到: {cron_file}")
    print("\n使用说明:")
    print("1. 查看cron配置: cat {cron_file}")
    print("2. 编辑crontab: crontab -e")
    print("3. 复制上面的配置并保存")
    print("4. 验证cron任务: crontab -l")
    print("\n系统将自动执行:")
    print("• 每日8:00: 运行公众号监控（不同步到飞书）")
    print("• 每周一9:00: 运行完整监控（包含飞书同步）")
    print("• 每月1号10:00: 清理30天前的旧文件")
    
    return cron_file

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='公众号自动阅读与融资监控系统',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  %(prog)s --daily                   # 运行每日流水线
  %(prog)s --daily --sync            # 运行每日流水线并同步到飞书
  %(prog)s --test                    # 运行测试模式
  %(prog)s --status                  # 查看系统状态
  %(prog)s --cleanup 7               # 清理7天前的旧文件
  %(prog)s --setup-cron              # 设置cron定时任务

系统组件:
  1. 公众号内容抓取 (wechat_crawler)
  2. AI评估与决策 (ai_assessment_model)
  3. 飞书表格集成 (feishu_integration)
  4. 自动化工作流 (automated_workflow)

输出目录:
  • /home/workspace/output/daily_reports/     # 每日简报
  • /home/workspace/output/assessment_results/ # 评估结果
  • /home/workspace/output/import_files/      # 飞书导入文件
  • /home/workspace/logs/                     # 系统日志
        """
    )
    
    parser.add_argument('--daily', action='store_true', help='运行每日流水线')
    parser.add_argument('--sync', action='store_true', help='启用飞书表格同步')
    parser.add_argument('--test', action='store_true', help='运行测试模式')
    parser.add_argument('--status', action='store_true', help='查看系统状态')
    parser.add_argument('--cleanup', type=int, metavar='DAYS', help='清理N天前的旧文件')
    parser.add_argument('--setup-cron', action='store_true', help='设置cron定时任务')
    parser.add_argument('--days', type=int, default=1, help='抓取最近N天的数据（默认: 1）')
    parser.add_argument('--config', type=str, default="/home/workspace/wechat_config.json", 
                       help='配置文件路径（默认: wechat_config.json）')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("📱 公众号自动阅读与融资监控系统")
    print(f"⏰ 当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    
    if args.setup_cron:
        setup_cron_job()
        return
    
    # 初始化系统
    try:
        system = WeChatMonitorSystem(args.config)
    except Exception as e:
        print(f"❌ 系统初始化失败: {e}")
        sys.exit(1)
    
    if args.status:
        # 显示系统状态
        status = system.get_system_status()
        print("\n🔧 系统状态:")
        print(f"  版本: {status.get('version')}")
        print(f"  初始化时间: {status.get('initialized')}")
        print(f"  最后运行: {status.get('last_run', '从未运行')}")
        print(f"  总运行次数: {status.get('total_runs', 0)}")
        print(f"  成功运行: {status.get('successful_runs', 0)}")
        
        print("\n📁 文件系统:")
        fs_info = status.get("file_system", {})
        print(f"  输出目录: {fs_info.get('output_dir')}")
        print(f"  总文件数: {fs_info.get('total_files', 0)}")
        
        print("\n⚙️  配置信息:")
        config_info = status.get("config", {})
        print(f"  配置文件: {config_info.get('path')}")
        print(f"  监控公众号: {config_info.get('total_accounts', 0)} 个")
        
        print("\n✅ 组件状态:")
        for component, enabled in status.get("components", {}).items():
            status_icon = "✅" if enabled else "❌"
            print(f"  {status_icon} {component}")
        
        sys.exit(0)
    
    elif args.cleanup:
        # 清理旧文件
        deleted = system.cleanup_old_files(args.cleanup)
        print(f"\n🗑️  清理完成，删除了 {deleted} 个 {args.cleanup} 天前的旧文件")
        sys.exit(0)
    
    elif args.test:
        # 运行测试模式
        print("\n🧪 运行测试模式...")
        result = system.run_test_mode()
        
        if result.get("success"):
            print("\n✅ 测试模式执行成功!")
            print(f"⏱️  执行时长: {result.get('total_duration', 0):.1f}秒")
        else:
            print(f"\n❌ 测试模式执行失败: {result.get('reason', '未知错误')}")
            sys.exit(1)
    
    elif args.daily:
        # 运行每日流水线
        print(f"\n🚀 开始每日流水线执行...")
        print(f"   抓取天数: {args.days} 天")
        print(f"   飞书同步: {'启用' if args.sync else '禁用'}")
        
        result = system.run_daily_pipeline(days_back=args.days, sync_to_base=args.sync)
        
        if result.get("success"):
            print("\n✅ 每日流水线执行成功!")
            
            # 显示关键指标
            steps = result.get("steps", [])
            for step in steps:
                if step.get("name") == "公众号抓取":
                    crawl_result = step.get("result", {})
                    print(f"📱 公众号抓取: {crawl_result.get('total_funding', 0)} 条融资信息")
                
                elif step.get("name") == "AI评估":
                    assessment_result = step.get("result", {})
                    print(f"🤖 AI评估: {assessment_result.get('assessment_report', {}).get('total_assessments', 0)} 份报告")
                
                elif step.get("name") == "飞书集成" and args.sync:
                    integration_result = step.get("result", {})
                    sync_result = integration_result.get("sync_result", {})
                    print(f"🔄 飞书同步: {sync_result.get('successful', 0)} 条记录成功同步")
            
            print(f"⏱️  总执行时长: {result.get('total_duration', 0):.1f}秒")
            print(f"📋 详细报告: /home/workspace/output/system_reports/")
            
        else:
            print(f"\n❌ 每日流水线执行失败: {result.get('reason', '未知错误')}")
            sys.exit(1)
    
    else:
        # 显示帮助
        parser.print_help()
        print("\n💡 提示: 使用 --daily 参数开始每日监控")
        sys.exit(0)
    
    print(f"\n{'='*80}")
    print(f"🎉 系统执行完成于: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

if __name__ == "__main__":
    main()