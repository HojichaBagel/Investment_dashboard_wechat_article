#!/usr/bin/env python3
"""
测试微信公众号内容抓取模块
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import json
from datetime import datetime
from wechat_crawler import WeChatCrawler, FundingInfoExtractor, WeChatArticle

def test_config_loading():
    """测试配置文件加载"""
    print("=== 测试1: 配置文件加载 ===")
    
    try:
        with open("/home/workspace/wechat_config.json", 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        print(f"✓ 配置文件加载成功")
        print(f"- 监控公众号数量: {len(config['wechat_accounts'])}")
        print(f"- 解析规则数量: {len(config['parsing_rules'])}")
        
        # 显示前3个公众号
        print("\n监控公众号列表:")
        for i, account in enumerate(config['wechat_accounts'][:3], 1):
            print(f"  {i}. {account['name']} - {account['description']}")
        
        return True
        
    except Exception as e:
        print(f"✗ 配置文件加载失败: {e}")
        return False

def test_extractor():
    """测试融资信息提取器"""
    print("\n=== 测试2: 融资信息提取器 ===")
    
    try:
        extractor = FundingInfoExtractor()
        
        # 测试文本
        test_texts = [
            "AI初创公司DeepMind完成5000万美元A轮融资，红杉资本领投",
            "医疗科技公司HealthAI获1.2亿元B轮投资，高瓴资本、启明创投跟投",
            "Quantum Computing startup Qubit raised $30M Series A led by Sequoia",
            "消费品牌新零售完成8000万元Pre-A轮融资，今日资本投资"
        ]
        
        for i, text in enumerate(test_texts, 1):
            print(f"\n测试文本 {i}: {text}")
            
            # 创建模拟文章
            article = WeChatArticle(
                account_name="测试公众号",
                title="测试文章标题",
                content=text,
                url="https://example.com/test",
                publish_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            
            # 提取融资信息
            funding_infos = extractor.extract_funding_info(article)
            
            if funding_infos:
                for funding in funding_infos:
                    print(f"  ✓ 提取到融资信息:")
                    print(f"     公司: {funding['company_name']}")
                    print(f"     金额: {funding['funding_amount']}")
                    print(f"     轮次: {funding['funding_round']}")
                    print(f"     投资方: {', '.join(funding['investors'])}")
                    print(f"     行业: {funding['industry']}")
                    print(f"     置信度: {funding['extraction_confidence']:.3f}")
            else:
                print(f"  ✗ 未提取到融资信息")
        
        return True
        
    except Exception as e:
        print(f"✗ 提取器测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_crawler_simulation():
    """测试爬虫模拟功能"""
    print("\n=== 测试3: 爬虫模拟功能 ===")
    
    try:
        crawler = WeChatCrawler()
        
        # 测试单个公众号模拟
        test_account = "36氪Pro"
        print(f"测试公众号: {test_account}")
        
        articles = crawler.simulate_crawl(test_account, days_back=1)
        
        print(f"✓ 模拟抓取成功")
        print(f"- 获取文章数量: {len(articles)}")
        
        for i, article in enumerate(articles, 1):
            print(f"\n  文章 {i}:")
            print(f"    标题: {article.title}")
            print(f"    预览: {article.content[:100]}...")
            print(f"    发布时间: {article.publish_time}")
            print(f"    文章ID: {article.article_id}")
        
        # 检查数据库
        cursor = crawler.db_conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM articles")
        article_count = cursor.fetchone()[0]
        
        print(f"\n数据库状态:")
        print(f"- 文章记录数: {article_count}")
        
        return True
        
    except Exception as e:
        print(f"✗ 爬虫模拟失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_full_workflow():
    """测试完整工作流"""
    print("\n=== 测试4: 完整工作流 ===")
    
    try:
        crawler = WeChatCrawler()
        
        print("执行完整抓取和解析流程...")
        funding_data = crawler.crawl_and_parse(days_back=1)
        
        print(f"✓ 完整流程执行成功")
        print(f"- 处理公众号数量: {len(funding_data)}")
        
        total_funding = 0
        for account, fundings in funding_data.items():
            print(f"\n  {account}:")
            print(f"    提取融资信息: {len(fundings)} 条")
            total_funding += len(fundings)
            
            # 显示前2条高置信度信息
            high_conf = sorted(fundings, key=lambda x: x['extraction_confidence'], reverse=True)[:2]
            for funding in high_conf:
                if funding['extraction_confidence'] >= 0.7:
                    print(f"    - {funding['company_name']}: {funding['funding_amount']} ({funding['extraction_confidence']:.3f})")
        
        print(f"\n总计提取融资信息: {total_funding} 条")
        
        # 生成报告
        print("\n生成每日报告...")
        report = crawler.generate_daily_report()
        
        if "error" not in report:
            print(f"✓ 报告生成成功")
            print(f"- 处理文章: {report['summary']['articles_processed']}")
            print(f"- 融资事件: {report['summary']['funding_events_found']}")
            print(f"- 涉及公司: {report['summary']['unique_companies']}")
        else:
            print(f"✗ 报告生成失败: {report['error']}")
        
        return True
        
    except Exception as e:
        print(f"✗ 完整工作流失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_data_persistence():
    """测试数据持久化"""
    print("\n=== 测试5: 数据持久化 ===")
    
    try:
        # 检查生成的文件
        data_dir = "/home/workspace/data"
        
        print("检查生成的数据文件:")
        
        # 检查原始文章
        raw_articles_dir = os.path.join(data_dir, "raw_articles")
        if os.path.exists(raw_articles_dir):
            raw_files = os.listdir(raw_articles_dir)
            print(f"- 原始文章文件: {len(raw_files)} 个")
            if raw_files:
                print(f"  示例: {raw_files[0]}")
        
        # 检查解析结果
        parsed_dir = os.path.join(data_dir, "parsed_funding")
        if os.path.exists(parsed_dir):
            parsed_files = os.listdir(parsed_dir)
            print(f"- 解析结果文件: {len(parsed_files)} 个")
            if parsed_files:
                print(f"  示例: {parsed_files[0]}")
                
                # 读取一个文件查看内容
                sample_file = os.path.join(parsed_dir, parsed_files[0])
                with open(sample_file, 'r', encoding='utf-8') as f:
                    sample_data = json.load(f)
                    if sample_data:
                        print(f"  包含融资信息: {len(sample_data)} 条")
        
        # 检查数据库
        db_path = os.path.join(data_dir, "wechat_funding.db")
        if os.path.exists(db_path):
            import sqlite3
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # 检查表
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            print(f"- 数据库表: {len(tables)} 个")
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
                count = cursor.fetchone()[0]
                print(f"  {table[0]}: {count} 条记录")
            
            conn.close()
        
        # 检查汇总文件
        summary_file = "/home/workspace/today_funding_summary.json"
        if os.path.exists(summary_file):
            print(f"- 汇总文件: 存在")
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary = json.load(f)
                print(f"  提取日期: {summary.get('extraction_date', 'N/A')}")
        
        return True
        
    except Exception as e:
        print(f"✗ 数据持久化测试失败: {e}")
        return False

def main():
    """运行所有测试"""
    print("=" * 60)
    print("微信公众号融资信息监控系统 - 功能测试")
    print("=" * 60)
    
    # 确保数据目录存在
    os.makedirs("/home/workspace/data", exist_ok=True)
    
    tests = [
        ("配置文件加载", test_config_loading),
        ("融资信息提取器", test_extractor),
        ("爬虫模拟功能", test_crawler_simulation),
        ("完整工作流", test_full_workflow),
        ("数据持久化", test_data_persistence)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"测试 '{test_name}' 执行异常: {e}")
            results.append((test_name, False))
    
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    
    passed = 0
    for test_name, success in results:
        status = "✓ 通过" if success else "✗ 失败"
        print(f"{test_name:20} {status}")
        if success:
            passed += 1
    
    print(f"\n通过测试: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("\n✅ 所有测试通过!")
    else:
        print(f"\n❌ {len(tests) - passed} 个测试失败")
    
    # 显示下一步建议
    print("\n" + "=" * 60)
    print("下一步:")
    print("-" * 60)
    print("1. 查看生成的数据文件:")
    print("   - /home/workspace/data/raw_articles/")
    print("   - /home/workspace/data/parsed_funding/")
    print("   - /home/workspace/today_funding_summary.json")
    print("\n2. 运行完整工作流:")
    print("   python wechat_crawler.py")
    print("\n3. 集成到现有系统:")
    print("   - 调用 crawl_and_parse() 方法获取每日融资信息")
    print("   - 将结果同步到飞书表格")
    print("   - 配置定时任务自动执行")
    
    return all(success for _, success in results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)