# 公众号自动阅读与融资监控系统 - 完整使用指南

## 系统概述

### 核心功能
- **每日自动监测**：监控6个投资类公众号的融资信息
- **AI智能评估**：基于6个维度对项目进行综合评分
- **自动决策**：给出follow/not的初步投资建议
- **飞书集成**：自动同步结果到飞书多维表格
- **定时任务**：支持每日自动执行和手动触发

### 系统架构
```
┌─────────────────────────────────────────────┐
│           公众号监控系统                      │
├─────────────────────────────────────────────┤
│ 数据采集 → 信息解析 → AI评估 → 结果同步      │
└─────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────┐
│           飞书多维表格                        │
│ • 候选公司库（实时更新）                     │
│ • 融资数据 + AI评分 + 决策建议               │
└─────────────────────────────────────────────┘
```

## 快速开始

### 1. 环境准备
```bash
# 确保Python环境
python --version  # 需要Python 3.8+
pip install -r requirements.txt  # 如果缺少依赖
```

### 2. 系统配置
配置文件位于：`/home/workspace/wechat_config.json`

主要配置项：
- **监控公众号**：6个投资类公众号，支持中英文
- **解析规则**：融资信息提取的正则表达式
- **监控计划**：每日抓取时间和重试策略
- **输出设置**：最大公司数和置信度阈值

### 3. 运行系统

#### 模式1：每日自动运行（推荐）
```bash
python wechat_monitor_system.py --daily
```
- 自动抓取最新公众号内容
- 执行AI评估和决策
- 同步结果到飞书表格
- 生成系统报告

#### 模式2：手动运行
```bash
python wechat_monitor_system.py --manual --days-back 1
```
- 手动指定抓取天数
- 交互式确认每个步骤
- 查看详细日志

#### 模式3：测试模式
```bash
python wechat_monitor_system.py --test
```
- 使用模拟数据进行测试
- 不修改生产数据
- 验证系统功能完整性

#### 模式4：设置定时任务
```bash
python wechat_monitor_system.py --setup-cron
```
- 自动配置每日6:00运行
- 设置系统状态监控
- 配置日志轮转

## 系统组件详解

### 1. 微信公众号爬虫 (`wechat_crawler.py`)
**功能**：模拟公众号内容抓取和融资信息提取

核心类：
- `WeChatCrawler`：主爬虫类，管理整个抓取流程
- `FundingInfoExtractor`：融资信息提取器
- `WeChatArticle`：文章数据结构

**特点**：
- 支持中英文公众号
- 内置关键词匹配
- 异常处理和重试机制
- 本地缓存避免重复抓取

### 2. AI评估模型 (`ai_assessment_model.py`)
**功能**：基于6个维度进行项目评估

评估维度：
| 维度 | 权重 | 子维度 |
|------|------|--------|
| 市场机会 | 25% | 市场规模、增长潜力、竞争格局 |
| 技术实力 | 20% | 技术壁垒、创新能力、专利情况 |
| 商业模式 | 20% | 盈利模式、客户获取、扩展性 |
| 团队背景 | 15% | 创始人经验、团队完整性 |
| 融资情况 | 10% | 估值合理性、投资方背景 |
| 风险因素 | 10% | 监管风险、技术风险、市场风险 |

**决策逻辑**：
- 综合评分 ≥ 80 → STRONG_FOLLOW（强烈关注）
- 70-79 → FOLLOW（建议关注）
- 60-69 → WATCH（保持观察）
- < 60 → NOT_FOLLOW（暂不关注）

### 3. 自动化工作流 (`automated_workflow.py`)
**功能**：管理完整的处理流程

工作流步骤：
1. **内容抓取**：从公众号获取最新文章
2. **信息解析**：提取融资信息
3. **公司调研**：搜索公司背景信息
4. **AI评估**：执行6维度评估
5. **报告生成**：创建评估报告
6. **结果存储**：保存到本地文件

### 4. 飞书集成 (`feishu_integration.py`)
**功能**：与飞书多维表格同步数据

已集成表格：[候选公司库](https://sensetime.feishu.cn/base/XCpvbzWuyayJ8wsmTv7cpAB3npf)

同步字段：
- 公司基本信息（名称、行业、地区）
- 融资数据（金额、轮次、投资方）
- AI评估结果（评分、决策、置信度）
- 时间戳和来源信息

## 配置说明

### 监控公众号列表
系统默认监控6个公众号：

| 公众号名称 | 语言 | 优先级 | 特点 |
|------------|------|--------|------|
| Strictly VC | 英文 | 1 | 每日全球VC融资头条 |
| Term Sheet (Fortune) | 英文 | 1 | 权威投资分析 |
| 36氪Pro | 中文 | 1 | 国内创投头条 |
| 投资界 | 中文 | 2 | 专业投资媒体 |
| 钛媒体 | 中文 | 2 | 科技与投资交叉 |
| 硬科技投资观察 | 中文 | 3 | 硬科技赛道 |

### 自定义配置
编辑 `wechat_config.json` 文件：

```json
{
  "wechat_accounts": [
    {
      "name": "自定义公众号",
      "description": "公众号描述",
      "priority": 1,
      "keywords": ["关键词1", "关键词2"],
      "language": "zh",
      "expected_daily_articles": 3,
      "reliability_score": 0.9
    }
  ]
}
```

### 解析规则配置
系统内置的解析规则包括：
- 公司名称识别
- 融资金额提取
- 融资轮次判断
- 投资方信息提取

## 使用示例

### 示例1：每日自动运行
```bash
$ python wechat_monitor_system.py --daily

[2026-06-01 06:00:00] INFO - 公众号监控系统启动
[2026-06-01 06:00:05] INFO - 开始抓取公众号内容...
[2026-06-01 06:15:30] INFO - 抓取完成，发现12篇文章
[2026-06-01 06:20:45] INFO - 提取到8个融资事件
[2026-06-01 06:35:10] INFO - AI评估完成，生成5个评估报告
[2026-06-01 06:40:20] INFO - 同步到飞书表格成功
[2026-06-01 06:40:25] INFO - 系统运行完成，耗时40分25秒
```

### 示例2：查看系统状态
```bash
$ python wechat_monitor_system.py --status

系统状态报告
============
• 系统版本: 1.0.0
• 运行次数: 15
• 成功次数: 14
• 最近运行: 2026-06-01T06:40:25
• 组件状态: 全部正常
• 飞书连接: 正常
• 存储空间: 85MB可用
```

### 示例3：清理旧数据
```bash
$ python wechat_monitor_system.py --cleanup --days 7

清理7天前的数据：
• 删除旧日志文件: 15个
• 清理缓存文件: 8个
• 备份重要数据: 已备份
• 释放空间: 120MB
```

## 飞书表格使用

### 表格结构
系统自动维护的飞书表格包含以下字段：

**基本信息**
- 公司名称
- 所属行业
- 所在地区
- 成立时间
- 员工规模

**融资信息**
- 融资金额
- 融资轮次
- 投资方
- 融资时间
- 估值

**AI评估**
- 综合评分 (0-100)
- 决策建议 (FOLLOW/WATCH/NOT)
- 置信度 (0-1)
- 关键亮点
- 潜在风险

**系统信息**
- 数据来源
- 抓取时间
- 更新时间
- 系统版本

### 数据筛选和查询
使用飞书表格的筛选和排序功能：

1. **按评分筛选**：只看评分≥70的公司
2. **按决策筛选**：只看FOLLOW和STRONG_FOLLOW
3. **按时间排序**：最新的融资事件排在最前
4. **按行业分组**：查看特定赛道的公司

## 故障排除

### 常见问题

#### 问题1：抓取失败，日志显示网络错误
**解决方案**：
```bash
# 检查网络连接
ping weixin.qq.com

# 增加重试次数（修改配置）
# wechat_config.json -> monitoring_schedule -> retry_attempts: 5
```

#### 问题2：AI评估分数异常（全部为0或100）
**解决方案**：
```bash
# 运行测试模式验证评估模型
python wechat_monitor_system.py --test

# 检查评估规则配置
cat ai_assessment_model.py | grep -n "评分"
```

#### 问题3：飞书同步失败
**解决方案**：
```bash
# 检查飞书连接
python -c "from feishu_integration import FeishuBaseIntegration; fbi = FeishuBaseIntegration(); print(fbi.test_connection())"

# 验证表格权限
# 确保有对表格的写入权限
```

#### 问题4：系统占用内存过高
**解决方案**：
```bash
# 清理缓存
python wechat_monitor_system.py --cleanup

# 调整抓取范围（减少公众号数量）
# 修改 wechat_config.json -> wechat_accounts
```

### 日志文件
系统生成多个日志文件用于故障排查：

| 日志文件 | 位置 | 用途 |
|----------|------|------|
| 系统日志 | `logs/system.log` | 记录系统运行状态 |
| 抓取日志 | `logs/wechat_crawler.log` | 记录公众号抓取详情 |
| 错误日志 | `logs/error.log` | 记录错误和异常 |
| 访问日志 | `logs/access.log` | 记录API调用 |

查看日志：
```bash
# 查看最新系统日志
tail -f logs/system.log

# 查看今天的错误
grep "ERROR" logs/system.log | grep "$(date +%Y-%m-%d)"

# 查看特定公众号的抓取记录
grep "Strictly VC" logs/wechat_crawler.log
```

## 性能优化

### 内存优化
```python
# 在配置文件中调整
{
  "output_settings": {
    "max_companies_per_day": 15,  # 减少每日处理数量
    "save_raw_html": false,       # 不保存原始HTML
    "backup_days": 3              # 减少备份天数
  }
}
```

### 速度优化
```python
{
  "monitoring_schedule": {
    "daily_crawl_times": ["06:00"],  # 只运行一次
    "analysis_window_hours": 48,     # 增加时间窗口
    "retry_attempts": 2,             # 减少重试次数
    "retry_delay_seconds": 60        # 减少重试延迟
  }
}
```

### 准确性优化
1. **增加关键词**：在配置中添加更多行业关键词
2. **优化解析规则**：根据实际数据调整正则表达式
3. **校准评估模型**：基于历史投资决策调整评分权重

## 扩展开发

### 添加新的数据源
1. 创建新的爬虫类，继承 `BaseCrawler`
2. 实现 `crawl()` 和 `parse()` 方法
3. 在配置文件中注册新的数据源
4. 在 `WeChatMonitorSystem` 中集成

### 自定义评估规则
1. 修改 `ai_assessment_model.py` 中的权重
2. 添加新的评估维度
3. 调整决策阈值
4. 添加特殊规则（如行业偏好）

### 集成其他输出格式
系统支持输出到多种格式：
- JSON文件（用于数据分析）
- CSV文件（用于Excel导入）
- Markdown报告（用于文档）
- 飞书消息（用于即时通知）

## 安全注意事项

### 数据保护
1. **本地存储加密**：敏感配置使用环境变量
2. **访问控制**：飞书表格设置适当权限
3. **数据备份**：定期备份重要数据
4. **日志脱敏**：不记录敏感信息

### 合规使用
1. **遵守公众号使用条款**：不进行恶意爬取
2. **尊重版权**：不复制原文内容
3. **数据使用限制**：仅用于内部投资分析
4. **隐私保护**：不收集个人隐私信息

## 维护计划

### 每日维护
```bash
# 自动执行
python wechat_monitor_system.py --daily

# 检查系统状态
python wechat_monitor_system.py --status
```

### 每周维护
```bash
# 清理旧数据
python wechat_monitor_system.py --cleanup --days 7

# 备份重要数据
cp -r /home/workspace/data /backup/wechat_monitor_$(date +%Y%m%d)
```

### 每月维护
1. 更新公众号列表（根据质量调整）
2. 优化解析规则（基于准确率分析）
3. 校准AI模型（基于历史决策）
4. 检查系统依赖更新

## 技术支持

### 获取帮助
1. 查看系统文档：`cat README.md`
2. 运行帮助命令：`python wechat_monitor_system.py --help`
3. 查看示例：`examples/` 目录
4. 检查测试用例：运行 `test_*.py` 文件

### 报告问题
```bash
# 生成问题报告
python wechat_monitor_system.py --debug-report

# 查看错误信息
cat logs/error.log

# 检查系统配置
python -c "import json; print(json.dumps(json.load(open('wechat_config.json')), indent=2, ensure_ascii=False))"
```

## 版本历史

### v1.0.0 (2026-06-01)
- 初始版本发布
- 支持6个公众号监控
- 完整的AI评估模型
- 飞书表格集成
- 自动化工作流

### 未来版本规划
- v1.1.0：增加更多数据源（新闻、研报）
- v1.2.0：优化AI模型准确性
- v1.3.0：增加实时通知功能
- v2.0.0：支持多用户和团队协作

---

## 附录

### A. 配置文件示例
完整配置文件示例见 `wechat_config.json`

### B. API接口说明
如果需要与其他系统集成，系统提供以下API：

```python
# 获取今日融资事件
GET /api/today-funding-events

# 获取AI评估结果
GET /api/ai-assessments?date=2026-06-01

# 手动触发抓取
POST /api/trigger-crawl

# 获取系统状态
GET /api/system-status
```

### C. 数据格式说明
系统使用的数据格式：

**融资事件格式**：
```json
{
  "company_name": "公司名称",
  "funding_amount": "5000万美元",
  "funding_round": "A轮",
  "investors": ["红杉资本", "高瓴资本"],
  "industry": "人工智能",
  "source": "Strictly VC",
  "publish_date": "2026-06-01",
  "article_url": "https://example.com/article"
}
```

**AI评估报告格式**：
```json
{
  "company_name": "公司名称",
  "comprehensive_score": 85.5,
  "dimension_scores": {
    "market_opportunity": 88,
    "technology_strength": 82,
    "business_model": 86,
    "team_background": 90,
    "funding_situation": 80,
    "risk_factors": 78
  },
  "decision": "STRONG_FOLLOW",
  "confidence": 0.92,
  "key_highlights": ["技术壁垒高", "市场增长快", "团队背景优秀"],
  "potential_risks": ["竞争激烈", "监管风险"],
  "recommendations": ["建议深入尽调", "关注下一轮融资"]
}
```

### D. 命令行参数参考
完整命令行参数：
```bash
# 基本使用
python wechat_monitor_system.py [选项]

选项：
  --daily          每日自动运行模式
  --manual         手动运行模式
  --test           测试模式（使用模拟数据）
  --status         查看系统状态
  --cleanup        清理旧数据
  --setup-cron     设置定时任务
  --days-back N    抓取N天前的数据（默认：1）
  --help           显示帮助信息
  --version        显示版本信息

示例：
  python wechat_monitor_system.py --daily
  python wechat_monitor_system.py --manual --days-back 3
  python wechat_monitor_system.py --test --verbose
```

---

*文档最后更新：2026年6月1日*
*系统版本：1.0.0*
*作者：公众号监控系统开发团队*
*技术支持：商汤科技 Aily助手*
