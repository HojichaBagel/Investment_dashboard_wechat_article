#!/usr/bin/env python3
"""
公众号自动阅读与融资监控系统 - 自动化工作流

功能：
1. 每日定时执行公众号内容抓取
2. 融资信息解析和提取
3. AI评估与follow/not决策
4. 结果同步到飞书表格
5. 生成每日投资简报

使用方式：
1. 直接运行：python automated_workflow.py
2. 定时任务：配置cron或系统定时任务
"""

import json
import os
import sys
import logging
from datetime import datetime, timedelta
import sqlite3
from typing import Dict, List, Optional

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from wechat_crawler import WeChatCrawler
from ai_assessment_model import AssessmentPipeline

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/workspace/logs/automated_workflow.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AutomatedWorkflow:
    """自动化工作流管理类"""
    
    def __init__(self, config_path: str = "/home/workspace/wechat_config.json"):
        """初始化工作流"""
        self.config_path = config_path
        
        # 加载配置
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # 初始化组件
        self.crawler = WeChatCrawler(config_path)
        self.assessment_pipeline = AssessmentPipeline()
        
        # 工作流状态
        self.workflow_status = {
            "start_time": None,
            "end_time": None,
            "steps_completed": [],
            "steps_failed": [],
            "results": {}
        }
        
        # 创建输出目录
        os.makedirs("/home/workspace/output", exist_ok=True)
        os.makedirs("/home/workspace/output/daily_reports", exist_ok=True)
        os.makedirs("/home/workspace/output/assessment_results", exist_ok=True)
        
    def run_full_workflow(self, days_back: int = 1) -> Dict:
        """
        运行完整工作流
        
        步骤：
        1. 公众号内容抓取
        2. 融资信息提取
        3. AI评估与决策
        4. 结果汇总
        5. 生成报告
        
        返回: 工作流执行结果
        """
        logger.info("=" * 60)
        logger.info("开始执行公众号自动阅读与融资监控系统工作流")
        logger.info(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 60)
        
        self.workflow_status["start_time"] = datetime.now().isoformat()
        
        try:
            # 步骤1: 公众号内容抓取
            logger.info("\n步骤1: 公众号内容抓取")
            funding_data = self.step_crawl_content(days_back)
            
            # 如果没有数据，提前结束
            if not funding_data or sum(len(v) for v in funding_data.values()) == 0:
                logger.warning("未提取到融资信息，工作流提前结束")
                self.workflow_status["results"]["no_data"] = True
                return self._generate_workflow_report(success=False, reason="无融资数据")
            
            # 步骤2: AI评估与决策
            logger.info("\n步骤2: AI评估与follow/not决策")
            assessment_reports = self.step_assessment(funding_data)
            
            # 步骤3: 生成汇总报告
            logger.info("\n步骤3: 生成汇总报告")
            summary_report = self.step_generate_summary(assessment_reports)
            
            # 步骤4: 保存结果
            logger.info("\n步骤4: 保存结果")
            saved_files = self.step_save_results(funding_data, assessment_reports, summary_report)
            
            # 步骤5: 生成飞书表格数据（模拟）
            logger.info("\n步骤5: 准备飞书表格数据")
            base_data = self.step_prepare_base_data(assessment_reports)
            
            # 更新工作流状态
            self.workflow_status["end_time"] = datetime.now().isoformat()
            self.workflow_status["steps_completed"] = [
                "公众号抓取", "AI评估", "报告生成", "结果保存", "数据准备"
            ]
            
            # 生成最终报告
            final_report = self._generate_workflow_report(
                success=True,
                funding_data_count=sum(len(v) for v in funding_data.values()),
                assessment_count=len(assessment_reports),
                saved_files=saved_files
            )
            
            logger.info("\n" + "=" * 60)
            logger.info("工作流执行完成!")
            logger.info(f"执行时长: {self._calculate_duration()}秒")
            logger.info(f"处理融资信息: {sum(len(v) for v in funding_data.values())}条")
            logger.info(f"生成评估报告: {len(assessment_reports)}份")
            logger.info("=" * 60)
            
            return final_report
            
        except Exception as e:
            logger.error(f"工作流执行失败: {e}")
            import traceback
            traceback.print_exc()
            
            self.workflow_status["end_time"] = datetime.now().isoformat()
            self.workflow_status["steps_failed"].append(str(e))
            
            return self._generate_workflow_report(success=False, reason=str(e))
    
    def step_crawl_content(self, days_back: int = 1) -> Dict:
        """步骤1: 公众号内容抓取"""
        logger.info(f"开始抓取最近{days_back}天的公众号内容...")
        
        try:
            # 执行抓取和解析
            funding_data = self.crawler.crawl_and_parse(days_back)
            
            # 统计结果
            total_funding = sum(len(v) for v in funding_data.values())
            logger.info(f"抓取完成，从 {len(funding_data)} 个公众号提取到 {total_funding} 条融资信息")
            
            # 显示各公众号提取情况
            for account, fundings in funding_data.items():
                if fundings:
                    logger.info(f"  - {account}: {len(fundings)} 条")
                    # 显示前3条高置信度信息
                    high_conf = sorted(fundings, key=lambda x: x.get('extraction_confidence', 0), reverse=True)[:3]
                    for funding in high_conf:
                        if funding.get('extraction_confidence', 0) >= 0.7:
                            logger.info(f"    * {funding.get('company_name')}: {funding.get('funding_amount')}")
            
            # 保存原始数据
            today = datetime.now().strftime("%Y%m%d")
            raw_data_file = f"/home/workspace/output/raw_funding_data_{today}.json"
            with open(raw_data_file, 'w', encoding='utf-8') as f:
                json.dump(funding_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"原始数据保存到: {raw_data_file}")
            
            return funding_data
            
        except Exception as e:
            logger.error(f"公众号抓取失败: {e}")
            raise
    
    def step_assessment(self, funding_data: Dict) -> List[Dict]:
        """步骤2: AI评估与决策"""
        logger.info("开始进行AI评估与follow/not决策...")
        
        try:
            # 执行评估流水线
            assessment_reports = self.assessment_pipeline.process_funding_data(funding_data)
            
            logger.info(f"评估完成，生成 {len(assessment_reports)} 份评估报告")
            
            # 统计决策分布
            decision_counts = {}
            for report in assessment_reports:
                decision = report["decision"]["type"]
                decision_counts[decision] = decision_counts.get(decision, 0) + 1
            
            logger.info("决策分布:")
            for decision, count in decision_counts.items():
                logger.info(f"  - {decision}: {count} 家公司")
            
            # 显示高分候选
            top_candidates = sorted(assessment_reports, key=lambda x: x["scores"]["final_score"], reverse=True)[:5]
            if top_candidates:
                logger.info("高分候选:")
                for i, candidate in enumerate(top_candidates, 1):
                    logger.info(f"  {i}. {candidate['company_name']} - {candidate['scores']['final_score']:.1f}分 ({candidate['decision']['type']})")
            
            return assessment_reports
            
        except Exception as e:
            logger.error(f"AI评估失败: {e}")
            raise
    
    def step_generate_summary(self, assessment_reports: List[Dict]) -> Dict:
        """步骤3: 生成汇总报告"""
        logger.info("生成每日汇总报告...")
        
        try:
            summary_report = self.assessment_pipeline.generate_summary_report(assessment_reports)
            
            # 保存汇总报告
            today = datetime.now().strftime("%Y%m%d")
            summary_file = f"/home/workspace/output/daily_reports/daily_summary_{today}.json"
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary_report, f, ensure_ascii=False, indent=2)
            
            logger.info(f"汇总报告保存到: {summary_file}")
            
            # 生成可读的文本报告
            text_report = self._generate_text_report(summary_report)
            text_file = f"/home/workspace/output/daily_reports/daily_summary_{today}.txt"
            with open(text_file, 'w', encoding='utf-8') as f:
                f.write(text_report)
            
            logger.info(f"文本报告保存到: {text_file}")
            
            return summary_report
            
        except Exception as e:
            logger.error(f"生成汇总报告失败: {e}")
            raise
    
    def _generate_text_report(self, summary_report: Dict) -> str:
        """生成可读的文本报告"""
        report_date = summary_report.get("generation_date", datetime.now().isoformat())
        total_companies = summary_report.get("total_companies_assessed", 0)
        avg_score = summary_report.get("score_statistics", {}).get("average_score", 0)
        
        report = f"""
{'='*60}
公众号自动阅读与融资监控系统 - 每日简报
生成时间: {report_date}
{'='*60}

📊 执行摘要
总评估公司数: {total_companies} 家
平均综合评分: {avg_score:.1f} 分

📈 决策分布
"""
        
        # 决策分布
        decision_dist = summary_report.get("decision_distribution", {})
        for decision, count in decision_dist.items():
            percentage = (count / total_companies * 100) if total_companies > 0 else 0
            report += f"- {decision}: {count} 家 ({percentage:.1f}%)\n"
        
        report += f"""
🏢 行业分布
"""
        
        # 行业分布
        industry_dist = summary_report.get("industry_distribution", {})
        for industry, count in industry_dist.items():
            report += f"- {industry}: {count} 家\n"
        
        report += f"""
🏆 今日最佳候选
"""
        
        # 最佳候选
        top_candidates = summary_report.get("top_candidates", [])[:5]
        for i, candidate in enumerate(top_candidates, 1):
            report += f"{i}. {candidate['company']}\n"
            report += f"   评分: {candidate['score']}分 | 行业: {candidate['industry']}\n"
            report += f"   融资金额: {candidate['funding_amount']} | 决策: {candidate['decision']}\n"
        
        report += f"""
💡 投资建议
"""
        
        # 投资建议
        recommendations = summary_report.get("recommendations", [])
        for rec in recommendations:
            report += f"- {rec}\n"
        
        report += f"""
📋 数据质量
平均置信度: {summary_report.get('data_quality_summary', {}).get('average_confidence', 0):.3f}
高置信度评估: {summary_report.get('data_quality_summary', {}).get('high_confidence_count', 0)} 个

{'='*60}
系统建议:
1. 对于「强烈关注」的公司，建议立即安排团队对接
2. 对于「建议关注」的公司，可安排初步接触会议
3. 定期回顾评估标准，优化评分模型
{'='*60}
"""
        
        return report
    
    def step_save_results(self, funding_data: Dict, assessment_reports: List[Dict], 
                         summary_report: Dict) -> Dict[str, str]:
        """步骤4: 保存结果"""
        logger.info("保存所有结果文件...")
        
        saved_files = {}
        today = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        try:
            # 保存评估结果
            assessment_file = f"/home/workspace/output/assessment_results/assessments_{today}.json"
            with open(assessment_file, 'w', encoding='utf-8') as f:
                json.dump(assessment_reports, f, ensure_ascii=False, indent=2)
            saved_files["assessment_results"] = assessment_file
            
            # 保存详细报告
            detailed_file = f"/home/workspace/output/assessment_results/detailed_{today}.json"
            detailed_data = {
                "execution_date": datetime.now().isoformat(),
                "funding_data_summary": {
                    "total_accounts": len(funding_data),
                    "total_funding_events": sum(len(v) for v in funding_data.values())
                },
                "assessment_summary": summary_report,
                "sample_assessments": assessment_reports[:3] if assessment_reports else []
            }
            with open(detailed_file, 'w', encoding='utf-8') as f:
                json.dump(detailed_data, f, ensure_ascii=False, indent=2)
            saved_files["detailed_report"] = detailed_file
            
            # 保存工作流状态
            status_file = f"/home/workspace/output/workflow_status_{today}.json"
            with open(status_file, 'w', encoding='utf-8') as f:
                json.dump(self.workflow_status, f, ensure_ascii=False, indent=2)
            saved_files["workflow_status"] = status_file
            
            logger.info(f"结果文件保存完成，共 {len(saved_files)} 个文件")
            for file_type, file_path in saved_files.items():
                logger.info(f"  - {file_type}: {file_path}")
            
            return saved_files
            
        except Exception as e:
            logger.error(f"保存结果失败: {e}")
            raise
    
    def step_prepare_base_data(self, assessment_reports: List[Dict]) -> List[Dict]:
        """步骤5: 准备飞书表格数据"""
        logger.info("准备飞书多维表格数据...")
        
        try:
            base_records = []
            
            for report in assessment_reports:
                # 提取关键信息
                record = {
                    "公司名称": report["company_name"],
                    "所属行业": report["industry"],
                    "融资金额": report["funding_info"]["amount"],
                    "融资轮次": report["funding_info"]["round"],
                    "投资机构": ", ".join(report["funding_info"]["investors"]),
                    "数据来源": report["funding_info"]["source"],
                    "评估日期": report["assessment_date"][:10],  # 取日期部分
                    "综合评分": round(report["scores"]["final_score"], 1),
                    "AI决策": report["decision"]["type"],
                    "决策置信度": round(report["decision"]["confidence"], 3),
                    "关键亮点": "; ".join(report["key_findings"]) if report["key_findings"] else "无",
                    "潜在风险": self._extract_risks(report["risk_analysis"]),
                    "下一步建议": "; ".join(report["decision"]["next_steps"][:2]),
                    "数据质量": round(report["data_quality"]["overall_confidence"], 3),
                    "原文链接": report.get("funding_info", {}).get("article_url", "无")
                }
                
                # 添加维度评分
                for dimension, score in report["scores"]["dimension_scores"].items():
                    record[f"{dimension}评分"] = round(score, 1)
                
                base_records.append(record)
            
            # 保存为JSON文件（可用于飞书表格导入）
            today = datetime.now().strftime("%Y%m%d")
            base_file = f"/home/workspace/output/base_records_{today}.json"
            with open(base_file, 'w', encoding='utf-8') as f:
                json.dump(base_records, f, ensure_ascii=False, indent=2)
            
            logger.info(f"飞书表格数据准备完成，共 {len(base_records)} 条记录")
            logger.info(f"数据文件: {base_file}")
            
            # 显示前3条记录
            if base_records:
                logger.info("示例记录:")
                for i, record in enumerate(base_records[:3], 1):
                    logger.info(f"  {i}. {record['公司名称']} - {record['融资金额']} ({record['AI决策']})")
            
            return base_records
            
        except Exception as e:
            logger.error(f"准备飞书表格数据失败: {e}")
            raise
    
    def _extract_risks(self, risk_analysis: Dict) -> str:
        """提取风险信息"""
        risks = []
        for risk_type, description in risk_analysis.items():
            if "高" in description:
                risks.append(f"{risk_type}:高风险")
            elif "中" in description:
                risks.append(f"{risk_type}:中风险")
            else:
                risks.append(f"{risk_type}:低风险")
        
        return "; ".join(risks) if risks else "风险可控"
    
    def _generate_workflow_report(self, success: bool, **kwargs) -> Dict:
        """生成工作流执行报告"""
        report = {
            "workflow_name": "公众号自动阅读与融资监控系统",
            "execution_date": datetime.now().isoformat(),
            "success": success,
            "duration_seconds": self._calculate_duration(),
            "start_time": self.workflow_status.get("start_time"),
            "end_time": self.workflow_status.get("end_time"),
            "steps_completed": self.workflow_status.get("steps_completed", []),
            "steps_failed": self.workflow_status.get("steps_failed", []),
            "system_info": {
                "python_version": sys.version,
                "working_directory": os.getcwd(),
                "config_file": self.config_path
            }
        }
        
        # 添加额外信息
        report.update(kwargs)
        
        # 保存报告
        today = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"/home/workspace/output/workflow_report_{today}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        logger.info(f"工作流报告保存到: {report_file}")
        
        return report
    
    def _calculate_duration(self) -> float:
        """计算执行时长（秒）"""
        if self.workflow_status["start_time"] and self.workflow_status["end_time"]:
            start = datetime.fromisoformat(self.workflow_status["start_time"].replace('Z', '+00:00'))
            end = datetime.fromisoformat(self.workflow_status["end_time"].replace('Z', '+00:00'))
            return (end - start).total_seconds()
        return 0.0
    
    def cleanup_old_files(self, days_to_keep: int = 7):
        """清理旧文件"""
        logger.info(f"清理 {days_to_keep} 天前的旧文件...")
        
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            files_deleted = 0
            
            # 清理输出目录
            output_dirs = [
                "/home/workspace/output/daily_reports",
                "/home/workspace/output/assessment_results",
                "/home/workspace/output"
            ]
            
            for output_dir in output_dirs:
                if os.path.exists(output_dir):
                    for filename in os.listdir(output_dir):
                        filepath = os.path.join(output_dir, filename)
                        if os.path.isfile(filepath):
                            # 检查文件修改时间
                            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
                            if mtime < cutoff_date:
                                os.remove(filepath)
                                files_deleted += 1
                                logger.debug(f"删除旧文件: {filepath}")
            
            logger.info(f"清理完成，删除了 {files_deleted} 个旧文件")
            
        except Exception as e:
            logger.warning(f"清理旧文件时出错: {e}")

def run_daily_workflow():
    """运行每日工作流（供定时任务调用）"""
    print("=" * 60)
    print("公众号自动阅读与融资监控系统 - 每日工作流")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 创建工作流实例
    workflow = AutomatedWorkflow()
    
    try:
        # 运行完整工作流（抓取最近1天的数据）
        result = workflow.run_full_workflow(days_back=1)
        
        if result.get("success"):
            print("\n✅ 工作流执行成功!")
            print(f"执行时长: {result.get('duration_seconds', 0):.1f}秒")
            
            if "funding_data_count" in result:
                print(f"处理融资信息: {result['funding_data_count']}条")
            if "assessment_count" in result:
                print(f"生成评估报告: {result['assessment_count']}份")
            
            # 显示保存的文件
            if "saved_files" in result:
                print(f"\n生成文件:")
                for file_type, file_path in result["saved_files"].items():
                    print(f"  - {file_type}: {os.path.basename(file_path)}")
            
            # 读取并显示文本报告
            today = datetime.now().strftime("%Y%m%d")
            text_report_file = f"/home/workspace/output/daily_reports/daily_summary_{today}.txt"
            if os.path.exists(text_report_file):
                print(f"\n📋 每日简报已生成: {text_report_file}")
                with open(text_report_file, 'r', encoding='utf-8') as f:
                    print(f.read())
        
        else:
            print(f"\n❌ 工作流执行失败")
            if "reason" in result:
                print(f"失败原因: {result['reason']}")
        
        # 清理旧文件（保留最近7天）
        workflow.cleanup_old_files(days_to_keep=7)
        
    except KeyboardInterrupt:
        print("\n⏹️ 工作流被用户中断")
    except Exception as e:
        print(f"\n❌ 工作流执行异常: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print(f"\n{'='*60}")
    print(f"工作流结束于: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    return result.get("success", False) if "result" in locals() else False

def create_cron_job():
    """创建cron定时任务配置"""
    cron_config = """
# 公众号自动阅读与融资监控系统 - 定时任务配置
# 每日早上8点执行（避开公众号推送高峰）

# 使用crontab -e添加以下行：
0 8 * * * cd /home/workspace && /usr/bin/python3 automated_workflow.py >> /home/workspace/logs/cron.log 2>&1

# 可选：测试模式（每小时执行一次）
# 0 * * * * cd /home/workspace && /usr/bin/python3 automated_workflow.py --test >> /home/workspace/logs/cron_test.log 2>&1

# 可选：周末不执行（只工作日执行）
# 0 8 * * 1-5 cd /home/workspace && /usr/bin/python3 automated_workflow.py >> /home/workspace/logs/cron.log 2>&1
"""
    
    cron_file = "/home/workspace/cron_config.txt"
    with open(cron_file, 'w', encoding='utf-8') as f:
        f.write(cron_config)
    
    print(f"Cron配置已保存到: {cron_file}")
    print("\n使用说明:")
    print("1. 复制上面的cron配置")
    print("2. 运行: crontab -e")
    print("3. 粘贴配置并保存")
    print("4. 系统将在每日早上8点自动执行工作流")

def test_workflow():
    """测试工作流（快速模式）"""
    print("=" * 60)
    print("公众号自动阅读与融资监控系统 - 测试模式")
    print("=" * 60)
    
    # 创建测试配置
    test_config = {
        "wechat_accounts": [
            {
                "name": "测试公众号",
                "description": "测试用公众号",
                "priority": 1,
                "keywords": ["测试"],
                "language": "zh",
                "expected_daily_articles": 1,
                "reliability_score": 0.9
            }
        ],
        "parsing_rules": {
            "company_name_patterns": ["([\\u4e00-\\u9fa5a-zA-Z0-9&]+)(?:公司|科技|技术|智能|数据)"],
            "funding_amount_patterns": ["(\\d+(?:\\.\\d+)?)\\s*(?:万|千万|亿|百万|十亿)?\\s*(?:元|人民币|RMB)"],
            "round_patterns": ["(?:种子|天使|Pre-A|A|B|C|D|E|战略)(?:轮|阶段)"],
            "investor_patterns": ["(?:领投|跟投|投资方)[：:]\\s*([^，。\\n]+)"]
        },
        "monitoring_schedule": {
            "daily_crawl_times": ["06:00"],
            "analysis_window_hours": 1,
            "retry_attempts": 1,
            "retry_delay_seconds": 300
        },
        "output_settings": {
            "max_companies_per_day": 20,
            "min_confidence_score": 0.7,
            "save_raw_html": True,
            "backup_days": 7
        }
    }
    
    test_config_file = "/home/workspace/test_config.json"
    with open(test_config_file, 'w', encoding='utf-8') as f:
        json.dump(test_config, f, ensure_ascii=False, indent=2)
    
    # 运行测试工作流
    workflow = AutomatedWorkflow(test_config_file)
    result = workflow.run_full_workflow(days_back=0)  # 当天数据
    
    # 清理测试配置
    if os.path.exists(test_config_file):
        os.remove(test_config_file)
    
    return result

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='公众号自动阅读与融资监控系统')
    parser.add_argument('--test', action='store_true', help='测试模式')
    parser.add_argument('--cron', action='store_true', help='生成cron配置')
    parser.add_argument('--days', type=int, default=1, help='抓取最近N天的数据（默认: 1）')
    parser.add_argument('--cleanup', type=int, help='清理N天前的旧文件')
    
    args = parser.parse_args()
    
    if args.cron:
        create_cron_job()
    elif args.test:
        test_workflow()
    elif args.cleanup:
        workflow = AutomatedWorkflow()
        workflow.cleanup_old_files(days_to_keep=args.cleanup)
    else:
        # 正常执行
        success = run_daily_workflow()
        sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()