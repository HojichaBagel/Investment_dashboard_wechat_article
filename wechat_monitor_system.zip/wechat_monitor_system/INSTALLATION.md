# 公众号监控系统 - 安装与启动指南

## 系统要求

### 硬件要求
- 内存：至少 2GB RAM
- 存储：至少 500MB 可用空间
- 网络：稳定的互联网连接

### 软件要求
- 操作系统：Linux/macOS/Windows (WSL2)
- Python：3.8 或更高版本
- 包管理器：pip

## 快速安装

### 步骤1：下载系统文件
```bash
# 假设系统文件已放置在 /home/workspace 目录
cd /home/workspace

# 验证文件完整性
ls -la *.py *.json *.md
```

### 步骤2：安装Python依赖
```bash
# 创建虚拟环境（可选但推荐）
python -m venv venv
source venv/bin/activate  # Linux/macOS
# 或 venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

如果没有 requirements.txt，手动安装：
```bash
pip install beautifulsoup4 lxml requests jsonlines
```

### 步骤3：配置系统
```bash
# 查看默认配置
cat wechat_config.json

# 如果需要自定义配置
cp wechat_config.json wechat_config.custom.json
# 编辑自定义配置文件
```

### 步骤4：测试安装
```bash
# 运行测试脚本
python test_wechat_crawler.py

# 测试评估模型
python debug_assessment.py
```

## 首次运行

### 方法1：使用测试模式（推荐）
```bash
python wechat_monitor_system.py --test
```

### 方法2：手动运行（控制详细输出）
```bash
python wechat_monitor_system.py --manual --verbose
```

### 方法3：查看系统状态
```bash
python wechat_monitor_system.py --status
```

## 配置定时任务

### Linux/macOS (使用cron)
```bash
# 设置每日早上6点自动运行
python wechat_monitor_system.py --setup-cron

# 或手动添加cron任务
crontab -e
# 添加以下行：
0 6 * * * cd /home/workspace && python wechat_monitor_system.py --daily >> /home/workspace/logs/cron.log 2>&1
```

### Windows (使用任务计划程序)
```bash
# 生成Windows任务脚本
python wechat_monitor_system.py --setup-windows-task
```

## 验证安装

### 检查组件状态
```bash
# 运行完整验证
python -c "
import sys
sys.path.append('.')
from wechat_crawler import WeChatCrawler
from ai_assessment_model import AssessmentPipeline
from feishu_integration import FeishuBaseIntegration

print('✓ WeChatCrawler 加载成功')
print('✓ AssessmentPipeline 加载成功')
print('✓ FeishuBaseIntegration 加载成功')
print('所有组件验证通过！')
"
```

### 测试飞书连接
```bash
# 测试飞书表格连接（需要飞书权限）
python -c "
import sys
sys.path.append('.')
from feishu_integration import FeishuBaseIntegration
try:
    fbi = FeishuBaseIntegration()
    print('✓ 飞书连接测试成功')
except Exception as e:
    print(f'✗ 飞书连接测试失败: {e}')
"
```

## 故障排除

### 常见安装问题

#### 问题1：Python版本不兼容
```bash
# 检查Python版本
python --version

# 如果需要安装Python 3.8+
# Ubuntu/Debian: sudo apt install python3.8 python3-pip
# macOS: brew install python@3.8
```

#### 问题2：依赖安装失败
```bash
# 使用国内镜像源
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 或逐个安装
pip install beautifulsoup4
pip install lxml
pip install requests
pip install jsonlines
```

#### 问题3：权限不足
```bash
# 创建必要的目录
mkdir -p /home/workspace/logs
mkdir -p /home/workspace/data
mkdir -p /home/workspace/backup

# 确保有写入权限
chmod 755 /home/workspace/logs
```

#### 问题4：配置文件错误
```bash
# 验证JSON格式
python -m json.tool wechat_config.json > /dev/null && echo "✓ JSON格式正确"

# 备份并重置配置
cp wechat_config.json wechat_config.json.backup
# 从原始设计文档恢复配置
```

## 升级系统

### 备份现有配置和数据
```bash
# 创建备份目录
mkdir -p /home/workspace/backup/$(date +%Y%m%d)

# 备份配置文件
cp wechat_config.json /home/workspace/backup/$(date +%Y%m%d)/

# 备份数据文件
cp -r /home/workspace/data /home/workspace/backup/$(date +%Y%m%d)/

# 备份日志（可选）
cp -r /home/workspace/logs /home/workspace/backup/$(date +%Y%m%d)/
```

### 更新系统文件
```bash
# 下载最新版本（根据实际情况）
# wget https://example.com/wechat_monitor_system.py
# wget https://example.com/wechat_crawler.py
# ...（其他文件）

# 或使用git
# git pull origin main
```

### 恢复配置
```bash
# 比较新旧配置差异
diff wechat_config.json /home/workspace/backup/$(date +%Y%m%d)/wechat_config.json

# 手动合并配置更改
```

## 卸载系统

### 保留数据
```bash
# 备份重要数据
mkdir -p ~/wechat_monitor_backup
cp -r /home/workspace/data ~/wechat_monitor_backup/
cp wechat_config.json ~/wechat_monitor_backup/
cp logs/system.log ~/wechat_monitor_backup/
```

### 清理文件
```bash
# 删除系统文件（谨慎操作）
rm -f *.py *.pyc *.json *.md
rm -rf __pycache__ venv

# 清理日志和数据（可选）
rm -rf logs/* data/* backup/*
```

## 获取帮助

### 查看帮助文档
```bash
# 系统帮助
python wechat_monitor_system.py --help

# 组件文档
python -c "import wechat_crawler; help(wechat_crawler.WeChatCrawler)"
python -c "import ai_assessment_model; help(ai_assessment_model.AssessmentPipeline)"
```

### 查看日志
```bash
# 实时查看系统日志
tail -f logs/system.log

# 查看错误日志
grep -i error logs/system.log | tail -20

# 查看今天的所有日志
grep "$(date +%Y-%m-%d)" logs/system.log
```

### 联系支持
- 查看完整文档：`wechat_monitor_system_guide.md`
- 运行诊断：`python wechat_monitor_system.py --debug-report`
- 提交问题：记录错误信息并联系开发团队

---

*安装指南版本：1.0.0*
*最后更新：2026年6月1日*
*系统要求可能随版本更新而变化*
