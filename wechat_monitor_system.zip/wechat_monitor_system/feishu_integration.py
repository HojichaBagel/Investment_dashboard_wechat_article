#!/usr/bin/env python3
"""
公众号监控系统与飞书表格集成模块

功能：
1. 将公众号监控系统的评估结果同步到飞书多维表格
2. 更新现有记录或创建新记录
3. 处理数据格式转换和字段映射
4. 提供批量同步和增量更新功能
"""

import json
import os
import sys
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import subprocess

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/workspace/logs/feishu_integration.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class FeishuBaseIntegration:
    """飞书多维表格集成类"""
    
    def __init__(self, base_url: str = "https://sensetime.feishu.cn/base/XCpvbzWuyayJ8wsmTv7cpAB3npf"):
        """初始化集成器"""
        self.base_url = base_url
        self.table_id = "tblVJBfE64Qz09qm"  # 候选公司库表格ID
        self.table_name = "候选公司库"
        
        # 字段映射：评估报告字段 -> 飞书表格字段
        self.field_mapping = {
            # 基础信息
            "company_name": "公司名称",
            "industry": "行业赛道",
            "funding_amount": "总融资额(万美元)",
            "funding_round": "最近融资轮次",
            "investors": "备注",  # 投资方信息放在备注中
            "source_account": "数据来源",
            "article_url": "公司链接",
            
            # 评估分数
            "technology_score": "技术评分",
            "market_score": "市场评分",
            "team_score": "团队评分",
            "financial_score": "财务评分",
            "risk_score": "风险评分",
            
            # 决策信息
            "ai_decision": "筛选状态",
            "assessment_date": "成立时间",  # 暂时用成立时间字段存储评估日期
            "confidence_score": "备注"  # 置信度也放在备注中
        }
        
        # 行业赛道映射
        self.industry_mapping = {
            "人工智能": "人工智能",
            "量子计算": "量子科技",
            "新能源": "清洁能源",
            "生物医药": "生物医药",
            "半导体": "半导体",
            "企业服务": "企业服务",
            "消费科技": "消费科技",
            "金融科技": "金融科技",
            "教育科技": "教育科技",
            "医疗健康": "医疗健康",
            "智能制造": "智能制造",
            "新材料": "新材料",
            "未分类": "其他"
        }
        
        # 融资轮次映射
        self.round_mapping = {
            "种子": "天使轮",
            "天使": "天使轮",
            "Pre-A": "Pre-A轮",
            "A": "A轮",
            "B": "B轮",
            "C": "C轮",
            "D": "D轮及以上",
            "E": "D轮及以上",
            "战略": "战略投资",
            "Series A": "A轮",
            "Series B": "B轮",
            "Series C": "C轮",
            "Series D": "D轮及以上",
            "Series E": "D轮及以上"
        }
        
        # 筛选状态映射
        self.decision_mapping = {
            "强烈关注": "已评估",
            "建议关注": "已评估",
            "保持观察": "待处理",
            "暂不关注": "已放弃"
        }
    
    def convert_assessment_to_base_record(self, assessment_report: Dict) -> Dict:
        """
        将评估报告转换为飞书表格记录
        
        参数:
            assessment_report: AI评估报告
            
        返回: 飞书表格记录格式
        """
        try:
            # 提取基础信息
            company_name = assessment_report.get("company_name", "未知公司")
            industry = assessment_report.get("industry", "未分类")
            funding_info = assessment_report.get("funding_info", {})
            scores = assessment_report.get("scores", {})
            decision = assessment_report.get("decision", {})
            data_quality = assessment_report.get("data_quality", {})
            
            # 构建飞书记录
            base_record = {}
            
            # 1. 基础信息
            base_record["公司名称"] = company_name
            base_record["行业赛道"] = self.industry_mapping.get(industry, "其他")
            
            # 发展阶段（基于融资轮次推断）
            funding_round = funding_info.get("round", "")
            stage = self._infer_stage(funding_round)
            base_record["发展阶段"] = stage
            
            # 成立时间（用评估日期）
            assessment_date = assessment_report.get("assessment_date", "")
            if assessment_date:
                try:
                    # 转换为日期格式
                    date_obj = datetime.fromisoformat(assessment_date.replace('Z', '+00:00'))
                    base_record["成立时间"] = date_obj.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    base_record["成立时间"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            else:
                base_record["成立时间"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # 2. 融资信息
            # 融资金额转换（转换为万美元）
            funding_amount = funding_info.get("amount", "")
            usd_amount = self._convert_funding_to_usd(funding_amount)
            base_record["总融资额(万美元)"] = usd_amount
            
            # 融资轮次
            base_record["最近融资轮次"] = self.round_mapping.get(funding_round, "未明确")
            
            # 估值范围（基于融资金额推断）
            valuation_range = self._infer_valuation_range(usd_amount)
            base_record["估值范围(亿美元)"] = valuation_range
            
            # 3. 评估分数
            dimension_scores = scores.get("dimension_scores", {})
            
            # 技术评分（从技术实力维度）
            tech_score = dimension_scores.get("技术实力", 5.0)
            base_record["技术评分"] = round(tech_score * 10, 1)  # 转换为0-100分
            
            # 市场评分（从市场机会维度）
            market_score = dimension_scores.get("市场机会", 5.0)
            base_record["市场评分"] = round(market_score * 10, 1)
            
            # 团队评分（从团队背景维度）
            team_score = dimension_scores.get("团队背景", 5.0)
            base_record["团队评分"] = round(team_score * 10, 1)
            
            # 财务评分（从融资情况维度）
            financial_score = dimension_scores.get("融资情况", 5.0)
            base_record["财务评分"] = round(financial_score * 10, 1)
            
            # 风险评分（从风险因素维度，注意风险分数越高表示风险越低）
            risk_score = dimension_scores.get("风险因素", 5.0)
            # 转换为风险评分（分数越高风险越高）
            risk_rating = 10 - risk_score  # 反转分数
            base_record["风险评分"] = round(risk_rating * 10, 1)
            
            # 4. 数据来源和状态
            source_account = funding_info.get("source", "")
            base_record["数据来源"] = f"公众号监控:{source_account}"
            
            ai_decision = decision.get("type", "保持观察")
            base_record["筛选状态"] = self.decision_mapping.get(ai_decision, "待处理")
            
            # 5. 备注和链接
            remarks = self._build_remarks(assessment_report)
            base_record["备注"] = remarks
            
            article_url = funding_info.get("article_url", "")
            if article_url and article_url.startswith("http"):
                base_record["公司链接"] = {"text": "原文链接", "link": article_url}
            
            # 6. 额外字段（用于数据质量追踪）
            base_record["_metadata"] = {
                "assessment_date": assessment_report.get("assessment_date", ""),
                "final_score": scores.get("final_score", 0),
                "decision_confidence": decision.get("confidence", 0),
                "data_quality": data_quality.get("overall_confidence", 0),
                "source_system": "公众号自动监控系统"
            }
            
            logger.info(f"转换完成: {company_name} -> 飞书记录")
            return base_record
            
        except Exception as e:
            logger.error(f"转换评估报告失败: {e}")
            raise
    
    def _infer_stage(self, funding_round: str) -> str:
        """根据融资轮次推断发展阶段"""
        if not funding_round:
            return "未明确"
        
        funding_round_lower = funding_round.lower()
        
        if "种子" in funding_round_lower or "天使" in funding_round_lower or "seed" in funding_round_lower:
            return "天使轮"
        elif "pre-a" in funding_round_lower or "pre a" in funding_round_lower:
            return "Pre-A轮"
        elif "a" in funding_round_lower and "b" not in funding_round_lower:
            return "A轮"
        elif "b" in funding_round_lower and "c" not in funding_round_lower:
            return "B轮"
        elif "c" in funding_round_lower and "d" not in funding_round_lower:
            return "C轮"
        elif "d" in funding_round_lower or "e" in funding_round_lower:
            return "D轮及以上"
        elif "战略" in funding_round_lower or "strategic" in funding_round_lower:
            return "战略投资"
        else:
            return "未明确"
    
    def _convert_funding_to_usd(self, funding_amount: str) -> float:
        """将融资金额转换为万美元"""
        if not funding_amount:
            return 0.0
        
        try:
            # 提取数字
            import re
            match = re.search(r'(\d+(?:\.\d+)?)', funding_amount.replace(',', ''))
            if not match:
                return 0.0
            
            amount = float(match.group(1))
            
            # 确定数量级
            if '亿' in funding_amount:
                amount *= 10000  # 亿人民币 -> 万人民币
            elif '千万' in funding_amount:
                amount *= 1000   # 千万人民币 -> 万人民币
            elif '万' in funding_amount:
                amount *= 1      # 万人民币 -> 万人民币
            elif '百万' in funding_amount and '美元' not in funding_amount:
                amount *= 0.01   # 百万人民币 -> 万人民币
            elif 'M' in funding_amount.upper() and '$' in funding_amount:
                amount *= 100    # 百万美元 -> 万美元
            elif 'B' in funding_amount.upper() and '$' in funding_amount:
                amount *= 100000 # 十亿美元 -> 万美元
            
            # 货币转换
            if '人民币' in funding_amount or 'RMB' in funding_amount or '元' in funding_amount:
                # 人民币转美元（假设汇率 7.2）
                amount /= 7.2
            
            # 确保单位为万美元
            return round(amount, 2)
            
        except:
            return 0.0
    
    def _infer_valuation_range(self, usd_amount: float) -> str:
        """根据融资金额推断估值范围"""
        if usd_amount <= 0:
            return "未披露"
        
        # 假设投后估值是融资金额的5-10倍
        estimated_valuation = usd_amount * 7.5  # 取中间值
        valuation_million = estimated_valuation / 100  # 万美元 -> 亿美元
        
        if valuation_million < 0.1:
            return "0-0.1亿"
        elif valuation_million < 0.5:
            return "0.1-0.5亿"
        elif valuation_million < 1:
            return "0.5-1亿"
        elif valuation_million < 5:
            return "1-5亿"
        elif valuation_million < 10:
            return "5-10亿"
        elif valuation_million < 50:
            return "10-50亿"
        else:
            return "50亿以上"
    
    def _build_remarks(self, assessment_report: Dict) -> str:
        """构建备注信息"""
        remarks_parts = []
        
        # 投资方信息
        funding_info = assessment_report.get("funding_info", {})
        investors = funding_info.get("investors", [])
        if investors and investors != ["未明确"]:
            remarks_parts.append(f"投资方: {', '.join(investors)}")
        
        # AI决策信息
        decision = assessment_report.get("decision", {})
        decision_type = decision.get("type", "")
        confidence = decision.get("confidence", 0)
        reasoning = decision.get("reasoning", "")
        
        if decision_type:
            remarks_parts.append(f"AI决策: {decision_type} (置信度: {confidence:.3f})")
        if reasoning:
            remarks_parts.append(f"决策理由: {reasoning}")
        
        # 关键发现
        key_findings = assessment_report.get("key_findings", [])
        if key_findings:
            remarks_parts.append(f"关键发现: {'; '.join(key_findings)}")
        
        # 下一步建议
        next_steps = decision.get("next_steps", [])
        if next_steps:
            remarks_parts.append(f"建议: {next_steps[0]}")
        
        # 数据质量
        data_quality = assessment_report.get("data_quality", {})
        overall_confidence = data_quality.get("overall_confidence", 0)
        remarks_parts.append(f"数据质量: {overall_confidence:.3f}")
        
        # 评估日期
        assessment_date = assessment_report.get("assessment_date", "")
        if assessment_date:
            date_part = assessment_date[:10]  # 取日期部分
            remarks_parts.append(f"评估日期: {date_part}")
        
        return " | ".join(remarks_parts)
    
    def sync_assessment_to_base(self, assessment_report: Dict) -> Dict:
        """
        同步单条评估记录到飞书表格
        
        参数:
            assessment_report: 单条评估报告
            
        返回: 同步结果
        """
        try:
            # 转换为飞书记录
            base_record = self.convert_assessment_to_base_record(assessment_report)
            
            # 构建同步数据
            sync_data = {
                "records": [
                    {
                        "fields": {k: v for k, v in base_record.items() if not k.startswith('_')}
                    }
                ]
            }
            
            # 保存为JSON文件
            temp_file = f"/home/workspace/temp_sync_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(sync_data, f, ensure_ascii=False, indent=2)
            
            # 使用aily-base CLI同步到飞书
            # 注意：这里使用模拟，实际部署时需要安装和配置aily-base
            company_name = assessment_report.get("company_name", "未知公司")
            
            logger.info(f"模拟同步到飞书表格: {company_name}")
            logger.info(f"同步数据已保存到: {temp_file}")
            
            # 模拟同步结果
            sync_result = {
                "success": True,
                "company_name": company_name,
                "base_url": self.base_url,
                "table_name": self.table_name,
                "fields_synced": list(base_record.keys()),
                "data_file": temp_file,
                "timestamp": datetime.now().isoformat(),
                "simulation": True  # 标记为模拟
            }
            
            # 在实际部署中，这里会调用:
            # aily-base sync --base-url {self.base_url} --table-id {self.table_id} --data {temp_file}
            
            return sync_result
            
        except Exception as e:
            logger.error(f"同步到飞书表格失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "company_name": assessment_report.get("company_name", "未知公司"),
                "timestamp": datetime.now().isoformat()
            }
    
    def batch_sync_assessments(self, assessment_reports: List[Dict]) -> Dict:
        """
        批量同步评估记录到飞书表格
        
        参数:
            assessment_reports: 评估报告列表
            
        返回: 批量同步结果
        """
        logger.info(f"开始批量同步 {len(assessment_reports)} 条评估记录")
        
        results = {
            "total": len(assessment_reports),
            "successful": 0,
            "failed": 0,
            "details": [],
            "start_time": datetime.now().isoformat()
        }
        
        for i, report in enumerate(assessment_reports, 1):
            company_name = report.get("company_name", f"公司#{i}")
            logger.info(f"同步 [{i}/{len(assessment_reports)}]: {company_name}")
            
            try:
                sync_result = self.sync_assessment_to_base(report)
                
                if sync_result.get("success"):
                    results["successful"] += 1
                    logger.info(f"  成功: {company_name}")
                else:
                    results["failed"] += 1
                    logger.error(f"  失败: {company_name} - {sync_result.get('error', '未知错误')}")
                
                results["details"].append(sync_result)
                
            except Exception as e:
                results["failed"] += 1
                logger.error(f"  异常: {company_name} - {e}")
                results["details"].append({
                    "success": False,
                    "company_name": company_name,
                    "error": str(e)
                })
        
        results["end_time"] = datetime.now().isoformat()
        
        # 计算统计信息
        if results["total"] > 0:
            success_rate = results["successful"] / results["total"] * 100
            results["success_rate"] = round(success_rate, 2)
        else:
            results["success_rate"] = 0
        
        logger.info(f"批量同步完成: 成功 {results['successful']}/{results['total']} ({results['success_rate']}%)")
        
        # 保存批量同步结果
        batch_result_file = f"/home/workspace/output/batch_sync_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(batch_result_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"批量同步结果保存到: {batch_result_file}")
        
        return results
    
    def generate_base_import_file(self, assessment_reports: List[Dict], output_file: str = None) -> str:
        """
        生成飞书表格导入文件
        
        参数:
            assessment_reports: 评估报告列表
            output_file: 输出文件路径（可选）
            
        返回: 生成的导入文件路径
        """
        logger.info(f"生成飞书表格导入文件，包含 {len(assessment_reports)} 条记录")
        
        if not output_file:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"/home/workspace/output/base_import_{timestamp}.json"
        
        try:
            # 转换所有记录
            base_records = []
            for report in assessment_reports:
                base_record = self.convert_assessment_to_base_record(report)
                # 移除元数据字段
                if "_metadata" in base_record:
                    del base_record["_metadata"]
                base_records.append({"fields": base_record})
            
            # 构建导入数据
            import_data = {
                "base_url": self.base_url,
                "table_id": self.table_id,
                "table_name": self.table_name,
                "generated_at": datetime.now().isoformat(),
                "total_records": len(base_records),
                "records": base_records
            }
            
            # 保存文件
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(import_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"导入文件生成成功: {output_file}")
            
            # 显示前3条记录
            if base_records:
                logger.info("示例记录:")
                for i, record in enumerate(base_records[:3], 1):
                    fields = record.get("fields", {})
                    company = fields.get("公司名称", "未知")
                    industry = fields.get("行业赛道", "未分类")
                    decision = fields.get("筛选状态", "未知")
                    logger.info(f"  {i}. {company} - {industry} ({decision})")
            
            return output_file
            
        except Exception as e:
            logger.error(f"生成导入文件失败: {e}")
            raise
    
    def check_existing_records(self, company_names: List[str]) -> Dict:
        """
        检查飞书表格中是否已存在这些公司
        
        参数:
            company_names: 公司名称列表
            
        返回: 存在性检查结果
        """
        logger.info(f"检查 {len(company_names)} 家公司是否已在飞书表格中存在")
        
        # 模拟检查结果
        # 在实际部署中，这里会查询飞书表格
        
        result = {
            "total_checked": len(company_names),
            "existing": [],
            "new": company_names.copy(),  # 假设都是新的
            "check_time": datetime.now().isoformat(),
            "simulation": True
        }
        
        # 模拟一些已存在的公司
        if len(company_names) > 0:
            # 假设第一家公司已存在
            result["existing"] = [company_names[0]]
            result["new"] = company_names[1:] if len(company_names) > 1 else []
        
        logger.info(f"检查完成: 已存在 {len(result['existing'])} 家，新增 {len(result['new'])} 家")
        
        return result

class IntegratedWorkflow:
    """集成工作流：公众号监控 + 飞书表格同步"""
    
    def __init__(self):
        """初始化集成工作流"""
        self.feishu_integration = FeishuBaseIntegration()
        
    def run_integrated_workflow(self, assessment_reports: List[Dict], 
                               sync_to_base: bool = True) -> Dict:
        """
        运行集成工作流
        
        参数:
            assessment_reports: 评估报告列表
            sync_to_base: 是否同步到飞书表格
            
        返回: 集成工作流结果
        """
        logger.info("=" * 60)
        logger.info("开始运行集成工作流")
        logger.info(f"评估报告数量: {len(assessment_reports)}")
        logger.info(f"同步到飞书表格: {sync_to_base}")
        logger.info("=" * 60)
        
        workflow_result = {
            "workflow_name": "公众号监控+飞书表格集成",
            "start_time": datetime.now().isoformat(),
            "total_assessments": len(assessment_reports),
            "sync_enabled": sync_to_base,
            "steps": []
        }
        
        try:
            # 步骤1: 准备数据
            logger.info("\n步骤1: 准备飞书表格数据")
            step1_result = self._prepare_base_data(assessment_reports)
            workflow_result["steps"].append({
                "name": "数据准备",
                "status": "completed",
                "result": step1_result
            })
            logger.info(f"数据准备完成: {len(step1_result.get('records', []))} 条记录")
            
            # 步骤2: 检查现有记录
            logger.info("\n步骤2: 检查现有记录")
            company_names = [r.get("company_name") for r in assessment_reports if r.get("company_name")]
            step2_result = self.feishu_integration.check_existing_records(company_names)
            workflow_result["steps"].append({
                "name": "记录检查",
                "status": "completed",
                "result": step2_result
            })
            logger.info(f"记录检查完成: 新增 {len(step2_result.get('new', []))} 条，已存在 {len(step2_result.get('existing', []))} 条")
            
            # 步骤3: 生成导入文件
            logger.info("\n步骤3: 生成导入文件")
            import_file = self.feishu_integration.generate_base_import_file(assessment_reports)
            workflow_result["steps"].append({
                "name": "文件生成",
                "status": "completed",
                "result": {"import_file": import_file}
            })
            logger.info(f"导入文件生成: {import_file}")
            
            # 步骤4: 同步到飞书表格（如果启用）
            if sync_to_base:
                logger.info("\n步骤4: 同步到飞书表格")
                step4_result = self.feishu_integration.batch_sync_assessments(assessment_reports)
                workflow_result["steps"].append({
                    "name": "表格同步",
                    "status": "completed" if step4_result.get("success_rate", 0) > 0 else "partial",
                    "result": step4_result
                })
                logger.info(f"表格同步完成: 成功率 {step4_result.get('success_rate', 0):.1f}%")
            else:
                logger.info("\n步骤4: 跳过表格同步（已禁用）")
                workflow_result["steps"].append({
                    "name": "表格同步",
                    "status": "skipped",
                    "result": {"reason": "同步功能已禁用"}
                })
            
            # 步骤5: 生成汇总报告
            logger.info("\n步骤5: 生成汇总报告")
            summary_report = self._generate_summary_report(workflow_result)
            workflow_result["summary"] = summary_report
            workflow_result["steps"].append({
                "name": "报告生成",
                "status": "completed",
                "result": {"summary_file": summary_report.get("file_path")}
            })
            
            workflow_result["end_time"] = datetime.now().isoformat()
            workflow_result["success"] = True
            
            logger.info("\n" + "=" * 60)
            logger.info("集成工作流执行成功!")
            logger.info(f"总处理记录: {len(assessment_reports)} 条")
            logger.info(f"生成导入文件: {import_file}")
            if sync_to_base:
                logger.info(f"同步成功率: {step4_result.get('success_rate', 0):.1f}%")
            logger.info("=" * 60)
            
            return workflow_result
            
        except Exception as e:
            logger.error(f"集成工作流执行失败: {e}")
            import traceback
            traceback.print_exc()
            
            workflow_result["end_time"] = datetime.now().isoformat()
            workflow_result["success"] = False
            workflow_result["error"] = str(e)
            
            return workflow_result
    
    def _prepare_base_data(self, assessment_reports: List[Dict]) -> Dict:
        """准备飞书表格数据"""
        base_records = []
        
        for report in assessment_reports:
            try:
                base_record = self.feishu_integration.convert_assessment_to_base_record(report)
                base_records.append(base_record)
            except Exception as e:
                logger.warning(f"准备数据失败: {report.get('company_name', '未知公司')} - {e}")
        
        return {
            "total_records": len(base_records),
            "records": base_records[:10],  # 只返回前10条作为示例
            "preparation_time": datetime.now().isoformat()
        }
    
    def _generate_summary_report(self, workflow_result: Dict) -> Dict:
        """生成汇总报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        summary_file = f"/home/workspace/output/integration_summary_{timestamp}.json"
        
        # 保存详细报告
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(workflow_result, f, ensure_ascii=False, indent=2)
        
        # 生成简化的文本报告
        text_report = f"""
{'='*60}
公众号监控系统与飞书表格集成报告
生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*60}

📊 执行摘要
总评估报告: {workflow_result.get('total_assessments', 0)} 份
同步到飞书表格: {'是' if workflow_result.get('sync_enabled') else '否'}
执行状态: {'成功' if workflow_result.get('success') else '失败'}

🔄 工作流步骤
"""
        
        for i, step in enumerate(workflow_result.get("steps", []), 1):
            text_report += f"{i}. {step.get('name', '未知步骤')}: {step.get('status', '未知')}\n"
        
        if "summary" in workflow_result:
            text_report += f"""
📈 同步统计
"""
            sync_result = None
            for step in workflow_result["steps"]:
                if step.get("name") == "表格同步" and "result" in step:
                    sync_result = step["result"]
                    break
            
            if sync_result:
                text_report += f"总记录数: {sync_result.get('total', 0)}\n"
                text_report += f"成功同步: {sync_result.get('successful', 0)}\n"
                text_report += f"同步失败: {sync_result.get('failed', 0)}\n"
                text_report += f"成功率: {sync_result.get('success_rate', 0):.1f}%\n"
        
        text_report += f"""
💾 生成文件
详细报告: {summary_file}

📋 下一步建议
1. 检查导入文件，确保数据格式正确
2. 使用飞书表格的导入功能或API批量导入
3. 验证数据同步结果
4. 配置定时任务，实现自动化同步

{'='*60}
"""
        
        # 保存文本报告
        text_file = summary_file.replace('.json', '.txt')
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(text_report)
        
        return {
            "file_path": summary_file,
            "text_file": text_file,
            "generated_at": datetime.now().isoformat()
        }

def test_integration():
    """测试集成功能"""
    print("=" * 60)
    print("公众号监控系统与飞书表格集成 - 测试")
    print("=" * 60)
    
    # 创建测试评估数据
    test_assessments = [
        {
            "company_name": "深度智能科技",
            "industry": "人工智能",
            "funding_info": {
                "amount": "1.2亿元",
                "round": "B轮",
                "investors": ["红杉中国", "高瓴资本"],
                "source": "36氪Pro",
                "article_url": "https://example.com/article1"
            },
            "scores": {
                "dimension_scores": {
                    "技术实力": 7.5,
                    "市场机会": 8.2,
                    "团队背景": 8.8,
                    "融资情况": 7.9,
                    "风险因素": 6.5
                },
                "final_score": 201.11
            },
            "decision": {
                "type": "强烈关注",
                "confidence": 0.85,
                "reasoning": "综合评分表现优异；团队背景表现突出",
                "next_steps": ["立即安排团队对接会议", "深入进行尽职调查"]
            },
            "key_findings": ["核心优势：团队背景", "获得顶级投资机构背书"],
            "risk_analysis": {
                "技术风险": "低 - 技术实力较强",
                "市场风险": "低 - 市场机会良好",
                "融资风险": "低 - 融资情况良好"
            },
            "data_quality": {
                "overall_confidence": 0.75
            },
            "assessment_date": datetime.now().isoformat()
        },
        {
            "company_name": "量子计算公司",
            "industry": "量子计算",
            "funding_info": {
                "amount": "5000万元",
                "round": "A轮",
                "investors": ["启明创投"],
                "source": "投资界",
                "article_url": "https://example.com/article2"
            },
            "scores": {
                "dimension_scores": {
                    "技术实力": 8.5,
                    "市场机会": 7.8,
                    "团队背景": 7.2,
                    "融资情况": 6.9,
                    "风险因素": 5.8
                },
                "final_score": 149.86
            },
            "decision": {
                "type": "建议关注",
                "confidence": 0.72,
                "reasoning": "综合评分表现良好；技术实力表现突出",
                "next_steps": ["安排初步接触会议", "收集更多公司信息"]
            },
            "key_findings": ["核心优势：技术实力", "处于前沿科技赛道"],
            "risk_analysis": {
                "技术风险": "中 - 技术前沿但商业化路径长",
                "市场风险": "中 - 市场处于早期阶段",
                "融资风险": "中 - 融资情况一般"
            },
            "data_quality": {
                "overall_confidence": 0.68
            },
            "assessment_date": datetime.now().isoformat()
        }
    ]
    
    print(f"测试数据: {len(test_assessments)} 条评估报告")
    
    # 测试单个记录转换
    print("\n1. 测试单个记录转换:")
    integration = FeishuBaseIntegration()
    
    for i, assessment in enumerate(test_assessments, 1):
        print(f"\n   记录 {i}: {assessment['company_name']}")
        try:
            base_record = integration.convert_assessment_to_base_record(assessment)
            print(f"     ✓ 转换成功")
            print(f"       公司名称: {base_record.get('公司名称')}")
            print(f"       行业赛道: {base_record.get('行业赛道')}")
            print(f"       融资金额: {base_record.get('总融资额(万美元)')} 万美元")
            print(f"       AI决策: {base_record.get('筛选状态')}")
        except Exception as e:
            print(f"     ✗ 转换失败: {e}")
    
    # 测试批量导入文件生成
    print("\n2. 测试批量导入文件生成:")
    try:
        import_file = integration.generate_base_import_file(test_assessments)
        print(f"     ✓ 导入文件生成成功: {import_file}")
        
        # 检查文件内容
        with open(import_file, 'r', encoding='utf-8') as f:
            import_data = json.load(f)
            print(f"       包含记录: {import_data.get('total_records', 0)} 条")
            print(f"       目标表格: {import_data.get('table_name')}")
    except Exception as e:
        print(f"     ✗ 文件生成失败: {e}")
    
    # 测试集成工作流
    print("\n3. 测试集成工作流:")
    workflow = IntegratedWorkflow()
    
    try:
        result = workflow.run_integrated_workflow(test_assessments, sync_to_base=False)
        print(f"     ✓ 集成工作流执行成功")
        print(f"       总处理记录: {result.get('total_assessments', 0)}")
        print(f"       执行步骤: {len(result.get('steps', []))}")
        
        if "summary" in result:
            summary = result["summary"]
            print(f"       报告文件: {summary.get('file_path')}")
    except Exception as e:
        print(f"     ✗ 集成工作流失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("集成测试完成!")
    print("=" * 60)
    
    return True

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='公众号监控系统与飞书表格集成')
    parser.add_argument('--test', action='store_true', help='运行测试')
    parser.add_argument('--input', type=str, help='评估报告JSON文件路径')
    parser.add_argument('--sync', action='store_true', help='启用同步到飞书表格')
    parser.add_argument('--output', type=str, help='输出文件路径')
    
    args = parser.parse_args()
    
    if args.test:
        success = test_integration()
        sys.exit(0 if success else 1)
    
    elif args.input:
        # 从文件加载评估报告
        if not os.path.exists(args.input):
            print(f"错误: 输入文件不存在: {args.input}")
            sys.exit(1)
        
        try:
            with open(args.input, 'r', encoding='utf-8') as f:
                assessment_reports = json.load(f)
            
            print(f"加载评估报告: {len(assessment_reports)} 条")
            
            # 运行集成工作流
            workflow = IntegratedWorkflow()
            result = workflow.run_integrated_workflow(
                assessment_reports, 
                sync_to_base=args.sync
            )
            
            if result.get("success"):
                print(f"\n✅ 集成工作流执行成功!")
                print(f"生成报告: {result.get('summary', {}).get('file_path', '未知')}")
            else:
                print(f"\n❌ 集成工作流执行失败: {result.get('error', '未知错误')}")
                sys.exit(1)
                
        except Exception as e:
            print(f"错误: {e}")
            sys.exit(1)
    
    else:
        print("请提供输入文件或使用 --test 运行测试")
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()